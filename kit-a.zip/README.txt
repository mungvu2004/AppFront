Render kit for prototype A (maquette) combo frames. Needs Blender 4.5.x.
  KIT_ROOT  folder that holds scripts/ assets/ shared/ (default: this folder)
  KIT_OUT   output folder for NNNN.jpg (default: KIT_ROOT/out)
  KIT_DEVICE=CPU to force CPU (default: OptiX, then CUDA, then CPU)
Render frames [a, b):  blender -b -P scripts/combo.py -- render --a 50 --b 75 --samples 160
Frames 0000-0049 = intro (rendered locally), 0050-0249 = A's move. Already rendered frames are skipped.
