"""Shared helpers + materials for the maquette scene (Blender 4.5, Cycles)."""
import math
import os
import bpy
import bmesh

# Paths: a render kit (Colab) sets KIT_ROOT, or the kit folder is found next to scripts/ (it has shared/);
# otherwise this is the dev checkout on F:.
_KIT = os.environ.get('KIT_ROOT') or (os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                                      if os.path.isdir(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'shared')) else None)
ASSETS = os.path.join(_KIT, 'assets', '') if _KIT else 'F:/App-review/homepage-v6/maquette/assets/'
SHARED = os.path.join(_KIT, 'shared', '') if _KIT else 'F:/App-review/homepage-v6/shared/'
IN_KIT = _KIT is not None
KIT = _KIT


# ---------------------------------------------------------------- node helpers
class NT:
    """Tiny node-tree builder: n = NT(mat); x = n.node('ShaderNodeMath', operation='ADD'); n.link(a, b)."""

    def __init__(self, mat):
        mat.use_nodes = True
        self.t = mat.node_tree
        self.t.nodes.clear()
        self.out = self.node('ShaderNodeOutputMaterial')

    def node(self, kind, **props):
        nd = self.t.nodes.new(kind)
        for k, v in props.items():
            setattr(nd, k, v)
        return nd

    def link(self, a, b):
        self.t.links.new(a, b)

    def math(self, op, a, b=None, clamp=False):
        nd = self.node('ShaderNodeMath', operation=op, use_clamp=clamp)
        for i, v in enumerate((a, b)):
            if v is None:
                continue
            if isinstance(v, (int, float)):
                nd.inputs[i].default_value = v
            else:
                self.link(v, nd.inputs[i])
        return nd.outputs[0]

    def mix(self, fac, a, b):
        nd = self.node('ShaderNodeMix', data_type='RGBA')
        for sock, v in ((nd.inputs[0], fac), (nd.inputs[6], a), (nd.inputs[7], b)):
            if isinstance(v, (int, float)):
                sock.default_value = v
            elif isinstance(v, tuple):
                sock.default_value = v if len(v) == 4 else (*v, 1)
            else:
                self.link(v, sock)
        return nd.outputs[2]

    def bsdf(self, **vals):
        b = self.node('ShaderNodeBsdfPrincipled')
        for k, v in vals.items():
            s = b.inputs[k]
            if isinstance(v, (int, float)):
                s.default_value = v
            elif isinstance(v, tuple):
                s.default_value = v if len(v) == len(s.default_value) else (*v, 1)
            else:
                self.link(v, s)
        self.link(b.outputs[0], self.out.inputs[0])
        return b

    def bump(self, height, strength, distance=0.0002, normal=None):
        b = self.node('ShaderNodeBump')
        b.inputs['Strength'].default_value = strength
        b.inputs['Distance'].default_value = distance
        self.link(height, b.inputs['Height'])
        if normal is not None:
            self.link(normal, b.inputs['Normal'])
        return b.outputs[0]

    def noise(self, vec, scale, detail=4.0, rough=0.5):
        nd = self.node('ShaderNodeTexNoise')
        nd.inputs['Scale'].default_value = scale
        nd.inputs['Detail'].default_value = detail
        nd.inputs['Roughness'].default_value = rough
        if vec is not None:
            self.link(vec, nd.inputs['Vector'])
        return nd

    def coord(self, which='Object'):
        return self.node('ShaderNodeTexCoord').outputs[which]

    def sep(self, vec):
        nd = self.node('ShaderNodeSeparateXYZ')
        self.link(vec, nd.inputs[0])
        return nd.outputs

    def mapping(self, vec, scale=(1, 1, 1), rot=(0, 0, 0), loc=(0, 0, 0)):
        nd = self.node('ShaderNodeMapping')
        nd.inputs['Scale'].default_value = scale
        nd.inputs['Rotation'].default_value = rot
        nd.inputs['Location'].default_value = loc
        self.link(vec, nd.inputs['Vector'])
        return nd.outputs[0]

    def image(self, path, vec, non_color=False):
        nd = self.node('ShaderNodeTexImage')
        nd.image = bpy.data.images.load(path, check_existing=True)
        if non_color:
            nd.image.colorspace_settings.name = 'Non-Color'
        nd.interpolation = 'Cubic'
        if vec is not None:
            self.link(vec, nd.inputs['Vector'])
        return nd


def line_mask(n, u, period, half_width):
    """1 where u (metres) is within half_width of a multiple of period."""
    t = n.math('DIVIDE', u, period)
    f = n.math('FRACT', n.math('ADD', t, 0.5))
    d = n.math('ABSOLUTE', n.math('SUBTRACT', f, 0.5))
    return n.math('LESS_THAN', n.math('MULTIPLY', d, period), half_width)


# ---------------------------------------------------------------- materials
def mat_wood():
    m = bpy.data.materials.new('ash_desk')
    n = NT(m)
    uv = n.mapping(n.coord('Object'), scale=(0.55, 0.55, 0.55), rot=(0, 0, math.radians(90)))
    diff = n.image(ASSETS + 'ash_veneer_diff_4k.jpg', uv)
    rough = n.image(ASSETS + 'ash_veneer_rough_2k.jpg', uv, True)
    nor = n.image(ASSETS + 'ash_veneer_nor_gl_2k.jpg', uv, True)
    nm = n.node('ShaderNodeNormalMap')
    nm.inputs['Strength'].default_value = 0.6
    n.link(nor.outputs[0], nm.inputs['Color'])
    hsv = n.node('ShaderNodeHueSaturation')
    hsv.inputs['Saturation'].default_value = 0.85
    hsv.inputs['Value'].default_value = 1.05
    n.link(diff.outputs[0], hsv.inputs['Color'])
    rr = n.node('ShaderNodeMapRange')
    rr.inputs['To Min'].default_value = 0.42
    rr.inputs['To Max'].default_value = 0.68
    n.link(rough.outputs[0], rr.inputs['Value'])
    n.bsdf(**{'Base Color': hsv.outputs[0], 'Roughness': rr.outputs[0], 'Normal': nm.outputs[0],
              'Coat Weight': 0.15, 'Coat Roughness': 0.35})
    return m


def mat_mat():
    """Green self-healing cutting mat with printed cream grid (object coords in metres, origin at mat centre)."""
    m = bpy.data.materials.new('cutting_mat')
    n = NT(m)
    co = n.coord('Object')
    x, y, _ = n.sep(co)
    gx = n.math('MAXIMUM', line_mask(n, x, 0.01, 0.00012), line_mask(n, x, 0.05, 0.00028))
    gy = n.math('MAXIMUM', line_mask(n, y, 0.01, 0.00012), line_mask(n, y, 0.05, 0.00028))
    grid = n.math('MAXIMUM', gx, gy)
    # Grid only inside an inset field (mat is 0.90 x 0.60; field 0.85 x 0.55).
    inx = n.math('LESS_THAN', n.math('ABSOLUTE', x), 0.4251)
    iny = n.math('LESS_THAN', n.math('ABSOLUTE', y), 0.2751)
    field = n.math('MULTIPLY', inx, iny)
    # 45-degree guide lines every 10 cm through the field.
    diag = line_mask(n, n.math('ADD', x, y), 0.1414, 0.00016)
    lines = n.math('MULTIPLY', n.math('MAXIMUM', grid, n.math('MULTIPLY', diag, 0.6)), field)
    # Mottled print + healed knife scores.
    mott = n.noise(co, 60.0, 6, 0.6)
    sc = n.noise(n.mapping(co, scale=(3, 900, 3), rot=(0, 0, math.radians(31))), 1.0, 2, 0.4)
    score = n.math('GREATER_THAN', sc.outputs[0], 0.72)
    sc2 = n.noise(n.mapping(co, scale=(900, 2.5, 3), rot=(0, 0, math.radians(-12))), 1.0, 2, 0.4)
    score = n.math('MAXIMUM', score, n.math('GREATER_THAN', sc2.outputs[0], 0.74))
    green = n.mix(n.math('MULTIPLY', mott.outputs[0], 0.35), (0.028, 0.085, 0.058), (0.04, 0.11, 0.075))
    green = n.mix(n.math('MULTIPLY', score, 0.35), green, (0.07, 0.15, 0.11))
    col = n.mix(lines, green, (0.62, 0.66, 0.52))
    rough = n.math('ADD', 0.62, n.math('MULTIPLY', score, 0.12))
    nrm = n.bump(n.math('ADD', n.math('MULTIPLY', mott.outputs[0], 0.4), n.math('MULTIPLY', score, -0.6)), 0.08)
    n.bsdf(**{'Base Color': col, 'Roughness': rough, 'Normal': nrm, 'Specular IOR Level': 0.35,
              'Sheen Weight': 0.15, 'Sheen Roughness': 0.6})
    return m


def mat_paper(img_path=None, name='paper', pencil=False):
    """Heavy cartridge paper; optional printed plan image on UVs (ink multiplies paper). pencil=True: red pixels of the
    image become waxy red pencil that catches the paper tooth instead of ink."""
    m = bpy.data.materials.new(name)
    n = NT(m)
    co = n.coord('Object')
    fib = n.noise(n.mapping(co, scale=(1, 3, 1)), 2200.0, 8, 0.7)
    blot = n.noise(co, 25.0, 3, 0.5)
    base = n.mix(n.math('MULTIPLY', blot.outputs[0], 0.25), (0.885, 0.865, 0.82), (0.905, 0.885, 0.84))
    if img_path:
        img = n.image(img_path, n.coord('UV'))
        img.extension = 'CLIP'
        # Ink sits slightly grey-blue, never pure black; keep halo of paper outside the image.
        ink = n.node('ShaderNodeRGBToBW')
        n.link(img.outputs[0], ink.inputs[0])
        inkf = n.math('SUBTRACT', 1.0, ink.outputs[0])
        inkf = n.math('MULTIPLY', inkf, img.outputs['Alpha'])
        rough = 0.88
        if pencil:
            r, g, _ = n.sep(img.outputs[0])
            red = n.math('MULTIPLY', n.math('SUBTRACT', r, g), 2.5, clamp=True)
            inkf = n.math('MULTIPLY', inkf, n.math('SUBTRACT', 1.0, red))
            tooth = n.noise(co, 5200.0, 3, 0.6)
            grain = n.node('ShaderNodeMapRange')
            grain.inputs['From Min'].default_value = 0.36
            grain.inputs['From Max'].default_value = 0.62
            n.link(tooth.outputs[0], grain.inputs['Value'])
            # thin anti-aliased strokes carry low alpha: lift coverage so the pencil reads at C's strength
            cover = n.math('MULTIPLY', n.math('MULTIPLY', red, img.outputs['Alpha']), 1.7, clamp=True)
            pen = n.math('MULTIPLY', cover, n.math('ADD', 0.6, n.math('MULTIPLY', grain.outputs[0], 0.4)))
        base = n.mix(inkf, base, (0.012, 0.013, 0.016))
        if pencil:
            base = n.mix(pen, base, (0.42, 0.045, 0.035))
            rough = n.math('SUBTRACT', 0.88, n.math('MULTIPLY', pen, 0.3))   # wax: a little sheen, never a glow
    else:
        rough = 0.88
    h = n.math('ADD', fib.outputs[0], n.math('MULTIPLY', blot.outputs[0], 0.3))
    n.bsdf(**{'Base Color': base, 'Roughness': rough, 'Normal': n.bump(h, 0.06, 0.00005),
              'Subsurface Weight': 0.12, 'Subsurface Radius': (1.0, 0.85, 0.7), 'Subsurface Scale': 0.0006,
              'Sheen Weight': 0.25, 'Sheen Roughness': 0.5, 'Specular IOR Level': 0.3})
    return m


def mat_foamboard(name='foamboard', skin=0.00018):
    """Foam board: paper skins on the faces, foam core on cut edges. Object local Y = across thickness,
    so the object's mesh must be centred on y=0 with thickness along local Y."""
    m = bpy.data.materials.new(name)
    n = NT(m)
    co = n.coord('Object')
    _, y, z = n.sep(co)
    ay = n.math('ABSOLUTE', y)
    # Generated attribute 'half_t' per object is not available; use a custom prop via Attribute node.
    attr = n.node('ShaderNodeAttribute', attribute_type='OBJECT', attribute_name='half_t')
    core = n.math('LESS_THAN', ay, n.math('SUBTRACT', attr.outputs['Fac'], skin))
    fib = n.noise(co, 3000.0, 6, 0.6)
    blot = n.noise(co, 180.0, 3, 0.5)
    skin_col = n.mix(n.math('MULTIPLY', blot.outputs[0], 0.2), (0.80, 0.78, 0.735), (0.83, 0.815, 0.775))
    core_col = (0.86, 0.835, 0.76)
    col = n.mix(core, skin_col, core_col)
    rough = n.math('ADD', 0.8, n.math('MULTIPLY', core, -0.25))
    h = n.math('ADD', fib.outputs[0], n.math('MULTIPLY', core, n.noise(co, 9000.0, 2, 0.5).outputs[0]))
    n.bsdf(**{'Base Color': col, 'Roughness': rough, 'Normal': n.bump(h, 0.05, 0.00003),
              'Subsurface Weight': n.math('ADD', 0.1, n.math('MULTIPLY', core, 0.25)),
              'Subsurface Radius': (1.0, 0.9, 0.75), 'Subsurface Scale': 0.0008,
              'Sheen Weight': 0.2, 'Sheen Roughness': 0.5, 'Specular IOR Level': 0.3})
    return m


def mat_greyboard(name='greyboard'):
    """Greyboard slab with white card laminated on top: up-facing faces white, edges/underside grey."""
    m = bpy.data.materials.new(name)
    n = NT(m)
    co = n.coord('Object')
    geo = n.node('ShaderNodeNewGeometry')
    _, _, nz = n.sep(geo.outputs['Normal'])
    top = n.math('GREATER_THAN', nz, 0.6)
    fib = n.noise(co, 2500.0, 8, 0.75)
    grey = n.mix(n.math('MULTIPLY', fib.outputs[0], 0.5), (0.27, 0.235, 0.195), (0.36, 0.32, 0.27))
    col = n.mix(top, grey, (0.80, 0.785, 0.745))
    n.bsdf(**{'Base Color': col, 'Roughness': 0.85, 'Normal': n.bump(fib.outputs[0], 0.12, 0.00004),
              'Subsurface Weight': 0.05, 'Subsurface Scale': 0.0004, 'Specular IOR Level': 0.3,
              'Sheen Weight': 0.2})
    return m


def mat_card(name='card', col=(0.74, 0.72, 0.68)):
    m = bpy.data.materials.new(name)
    n = NT(m)
    co = n.coord('Object')
    fib = n.noise(co, 2800.0, 8, 0.7)
    blot = n.noise(co, 120.0, 3, 0.5)
    c = n.mix(n.math('MULTIPLY', blot.outputs[0], 0.3), col, tuple(min(1, v * 1.06) for v in col))
    n.bsdf(**{'Base Color': c, 'Roughness': 0.86, 'Normal': n.bump(fib.outputs[0], 0.05, 0.00004),
              'Subsurface Weight': 0.08, 'Subsurface Scale': 0.0005, 'Sheen Weight': 0.2,
              'Specular IOR Level': 0.3})
    return m


def mat_acetate():
    m = bpy.data.materials.new('acetate')
    n = NT(m)
    n.bsdf(**{'Base Color': (0.96, 0.97, 0.97), 'Roughness': 0.04, 'Transmission Weight': 1.0, 'IOR': 1.49,
              'Coat Weight': 0.6, 'Coat Roughness': 0.03, 'Specular IOR Level': 0.7})
    return m


def mat_foam_tree(name, col):
    m = bpy.data.materials.new(name)
    n = NT(m)
    co = n.coord('Object')
    v = n.node('ShaderNodeTexVoronoi')
    v.inputs['Scale'].default_value = 1400.0
    n.link(co, v.inputs['Vector'])
    pores = n.noise(co, 900.0, 6, 0.65)
    h = n.math('ADD', v.outputs['Distance'], n.math('MULTIPLY', pores.outputs[0], 0.6))
    c = n.mix(n.math('MULTIPLY', pores.outputs[0], 0.5), col, tuple(v * 0.85 for v in col))
    n.bsdf(**{'Base Color': c, 'Roughness': 0.95, 'Normal': n.bump(h, 0.6, 0.0004),
              'Subsurface Weight': 0.3, 'Subsurface Radius': (1, 0.9, 0.7), 'Subsurface Scale': 0.0015,
              'Specular IOR Level': 0.2, 'Sheen Weight': 0.4, 'Sheen Roughness': 0.6})
    return m


def mat_twig():
    m = bpy.data.materials.new('twig')
    n = NT(m)
    nz = n.noise(n.mapping(n.coord('Object'), scale=(300, 300, 3000)), 1.0, 4, 0.6)
    c = n.mix(nz.outputs[0], (0.13, 0.085, 0.055), (0.22, 0.15, 0.10))
    n.bsdf(**{'Base Color': c, 'Roughness': 0.8, 'Normal': n.bump(nz.outputs[0], 0.3, 0.0001)})
    return m


def mat_metal(name, col, rough, aniso=0.0, rot=0.0):
    m = bpy.data.materials.new(name)
    n = NT(m)
    co = n.coord('Object')
    br = n.noise(n.mapping(co, scale=(20, 6000, 20)), 1.0, 3, 0.5)
    r = n.math('ADD', rough, n.math('MULTIPLY', br.outputs[0], 0.08))
    kw = {'Base Color': col, 'Metallic': 1.0, 'Roughness': r, 'Normal': n.bump(br.outputs[0], 0.04, 0.00002)}
    if aniso:
        kw.update({'Anisotropic': aniso, 'Anisotropic Rotation': rot})
    n.bsdf(**kw)
    return m


def mat_knurl(name, col, metallic, rough, pitch=0.0008):
    """Diamond knurl as bump (object coords: long axis = local Z)."""
    m = bpy.data.materials.new(name)
    n = NT(m)
    co = n.coord('Object')
    x, y, z = n.sep(co)
    u = n.math('MULTIPLY', n.math('ARCTAN2', y, x), 0.0042)  # approx arc length at r 4.2 mm
    a = n.math('SINE', n.math('MULTIPLY', n.math('ADD', u, z), 2 * math.pi / pitch))
    b = n.math('SINE', n.math('MULTIPLY', n.math('SUBTRACT', u, z), 2 * math.pi / pitch))
    h = n.math('MINIMUM', a, b)
    n.bsdf(**{'Base Color': col, 'Metallic': metallic, 'Roughness': rough,
              'Normal': n.bump(h, 0.5, 0.00012)})
    return m


def mat_plain(name, col, rough=0.5, metallic=0.0, **kw):
    m = bpy.data.materials.new(name)
    n = NT(m)
    n.bsdf(**{'Base Color': col, 'Roughness': rough, 'Metallic': metallic, **kw})
    return m


# ---------------------------------------------------------------- mesh helpers
def obj_from_bm(name, bm, mat=None, smooth=False):
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    ob = bpy.data.objects.new(name, me)
    bpy.context.collection.objects.link(ob)
    if mat:
        me.materials.append(mat)
    if smooth:
        for p in me.polygons:
            p.use_smooth = True
    return ob


def box(name, sx, sy, sz, mat=None, bevel=0.0, segs=2, loc=(0, 0, 0), angle=40):
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    bmesh.ops.scale(bm, vec=(sx, sy, sz), verts=bm.verts)
    ob = obj_from_bm(name, bm, mat)
    ob.location = loc
    if bevel:
        add_bevel(ob, bevel, segs, angle)
    return ob


def add_bevel(ob, width, segs=2, angle=40):
    md = ob.modifiers.new('bevel', 'BEVEL')
    md.width = width
    md.segments = segs
    md.limit_method = 'ANGLE'
    md.angle_limit = math.radians(angle)
    md.harden_normals = True
    for p in ob.data.polygons:
        p.use_smooth = True
    return md


def lathe(name, profile, steps=48, mat=None, smooth=True):
    """profile: list of (r, z) in metres, revolved around Z."""
    bm = bmesh.new()
    vs = [bm.verts.new((r, 0, z)) for r, z in profile]
    es = [bm.edges.new((vs[i], vs[i + 1])) for i in range(len(vs) - 1)]
    bmesh.ops.spin(bm, geom=vs + es, cent=(0, 0, 0), axis=(0, 0, 1), angle=2 * math.pi, steps=steps,
                   use_merge=True)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-7)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    return obj_from_bm(name, bm, mat, smooth)
