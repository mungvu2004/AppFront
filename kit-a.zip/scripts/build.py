"""Build the maquette scene and render one state.
blender -b -P build.py -- --p 0.5 --out still-mid.jpg [--samples 256] [--blend scene.blend] [--res 1920x1080]
"""
import math
import os
import sys
import time
import bpy
from mathutils import Vector, Quaternion

sys.path.insert(0, os.path.dirname(__file__))
import mq      # noqa: E402
import desk    # noqa: E402
import house   # noqa: E402

PLAN_PNG = mq.ASSETS + 'plan-print.png'   # make_print.mjs: site plan restyled as a fresh plot, no room labels
PLAN_VIEW = (-1.5, -1.5, 43.0, 37.0)   # plans.json viewBox, metres
PAPER_LOC = Vector((-0.04, 0.02, 0.0))
ENTRANCE = house.to_world(13.0, 9.0) + Vector((0, 0, 0.012))


def args():
    a = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
    out = {'p': 1.0, 'out': None, 'samples': 256, 'blend': None, 'res': '1920x1080'}
    for i in range(0, len(a), 2):
        out[a[i].lstrip('-')] = a[i + 1]
    out['p'] = float(out['p'])
    out['samples'] = int(out['samples'])
    return out


# ---------------------------------------------------------------- easing
def clamp01(t):
    return max(0.0, min(1.0, t))


def smoother(t):
    t = clamp01(t)
    return t * t * t * (t * (6 * t - 15) + 10)


def spring(t, damp=7.0, freq=7.0):
    """0 -> 1 with one small overshoot, settles by t = 1."""
    t = clamp01(t)
    if t >= 1:
        return 1.0
    return 1.0 - math.exp(-damp * t) * math.cos(freq * t) * (1 - t)


def win(p, a, b):
    return clamp01((p - a) / (b - a))


# ---------------------------------------------------------------- scene setup
def paper_uvs(ob, view=None):
    vx, vy, vw, vh = view or PLAN_VIEW
    uv = ob.data.uv_layers['UVMap']
    for lp in ob.data.loops:
        co = ob.data.vertices[lp.vertex_index].co + ob.location
        x = house.CX - co.x / house.S
        y = house.CY + co.y / house.S
        uv.data[lp.index].uv = ((x - vx) / vw, 1.0 - (y - vy) / vh)


def ghost_all_materials():
    """Wrap every material so an object/instancer custom prop 'ghost' (0..1) fades it out (0 = solid)."""
    for m in bpy.data.materials:
        if not m.use_nodes:
            continue
        t = m.node_tree
        out = next((n for n in t.nodes if n.type == 'OUTPUT_MATERIAL'), None)
        if out is None or not out.inputs['Surface'].is_linked:
            continue
        src = out.inputs['Surface'].links[0].from_socket
        a1 = t.nodes.new('ShaderNodeAttribute')
        a1.attribute_type, a1.attribute_name = 'OBJECT', 'ghost'
        a2 = t.nodes.new('ShaderNodeAttribute')
        a2.attribute_type, a2.attribute_name = 'INSTANCER', 'ghost'
        mx = t.nodes.new('ShaderNodeMath')
        mx.operation = 'MAXIMUM'
        t.links.new(a1.outputs['Fac'], mx.inputs[0])
        t.links.new(a2.outputs['Fac'], mx.inputs[1])
        tr = t.nodes.new('ShaderNodeBsdfTransparent')
        mix = t.nodes.new('ShaderNodeMixShader')
        t.links.new(mx.outputs[0], mix.inputs[0])
        t.links.new(src, mix.inputs[1])
        t.links.new(tr.outputs[0], mix.inputs[2])
        t.links.new(mix.outputs[0], out.inputs['Surface'])


def descendants(o):
    out, st = [], list(o.children)
    while st:
        x = st.pop()
        out.append(x)
        st += list(x.children)
    return out


def build(plan_png=PLAN_PNG, view=None, pencil=False):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    desk.build_desk(plan_png, pencil)
    pap = bpy.data.objects['paper']
    pap.location.x, pap.location.y = PAPER_LOC.x, PAPER_LOC.y
    paper_uvs(pap, view)
    bpy.data.images[os.path.basename(plan_png)].alpha_mode = 'STRAIGHT'
    top = pap.location.z + 0.00025
    h = house.build_house(top + 0.00003)
    cam_d = bpy.data.cameras.new('cam')
    cam_d.sensor_width = 36.0
    cam_d.dof.use_dof = True
    cam = bpy.data.objects.new('cam', cam_d)
    bpy.context.collection.objects.link(cam)
    bpy.context.scene.camera = cam
    ghost_all_materials()
    return h, cam


# ---------------------------------------------------------------- the moment, p in 0..1
CAM0 = dict(target=Vector((-0.04, 0.02, 0.0)), dist=1.25, elev=88.0, az=-87.0, focal=50.0, shift=-0.16, fstop=8.0,
            focus=Vector((-0.04, 0.02, 0.0)))
CAM1 = dict(target=Vector((-0.01, 0.0, 0.03)), dist=0.92, elev=20.0, az=-42.0, focal=50.0, shift=-0.17, fstop=3.2,
            focus=ENTRANCE)


def lerp(a, b, t):
    return a + (b - a) * t


def pose(cam, tgt, dist, el_deg, az_deg, focal, shift, fstop, fpt):
    el, az = math.radians(el_deg), math.radians(az_deg)
    pos = tgt + dist * Vector((math.cos(el) * math.cos(az), math.cos(el) * math.sin(az), math.sin(el)))
    cam.location = pos
    fwd = (tgt - pos).normalized()
    cam.rotation_mode = 'QUATERNION'
    cam.rotation_quaternion = fwd.to_track_quat('-Z', 'Y')
    cam.data.lens = focal
    cam.data.shift_x = shift
    cam.data.dof.aperture_fstop = fstop
    cam.data.dof.focus_distance = (fpt - pos).dot(fwd)


def lerp_cam(a, b, s, se=None, sa=None, sf=None):
    se, sa, sf = (s if v is None else v for v in (se, sa, sf))
    return (a['target'].lerp(b['target'], s), math.exp(lerp(math.log(a['dist']), math.log(b['dist']), s)),
            lerp(a['elev'], b['elev'], se), lerp(a['az'], b['az'], sa), lerp(a['focal'], b['focal'], s),
            lerp(a['shift'], b['shift'], s), math.exp(lerp(math.log(a['fstop']), math.log(b['fstop']), s)),
            a['focus'].lerp(b['focus'], sf))


def apply(p, h, cam):
    # camera: holds, then one long eased descent; elevation leads, azimuth trails a little
    pose(cam, *lerp_cam(CAM0, CAM1, smoother(win(p, 0.04, 1.0)), se=smoother(win(p, 0.04, 0.98)),
                        sa=smoother(win(p, 0.06, 1.0)), sf=smoother(win(p, 0.35, 0.9))))

    # ground-floor walls rise out of their printed lines, unfolding from a slight lean, rippling from the entrance
    g = [x for x in h['hinges'] if x['level'] == 0]
    ent = Vector((ENTRANCE.x, ENTRANCE.y, 0))
    g.sort(key=lambda x: (x.location.xy - ent.xy).length)
    for i, x in enumerate(g):
        a = 0.14 + 0.30 * i / max(1, len(g) - 1)
        t = win(p, a, a + 0.16)
        x.location.z = x['z0'] - x['h'] * (1.0 - spring(t, 7.0, 7.0))
        x.rotation_euler.x = math.radians(22.0) * x['fold_sign'] * (1.0 - smoother(t))
    # T1 furniture + stair push up through the print
    t = smoother(win(p, 0.36, 0.56))
    for o in h['levels'][0].children:
        if o.get('kind') in ('white', 'grey'):
            o.location.z = -0.034 * (1 - t)
    # upper floors settle from above, then the roofs; ghost in over the first part of the drop
    for lvl, (a, b) in ((1, (0.55, 0.72)), (2, (0.64, 0.80))):
        _drop(h['levels'][lvl], p, a, b, 0.09)
    _drop(h['roof'], p, 0.74, 0.90, 0.07)
    # trees are set down one by one
    trees = sorted(h['trees'], key=lambda o: o.location.xy.length)
    for i, o in enumerate(trees):
        a = 0.68 + 0.18 * i / max(1, len(trees) - 1)
        t = win(p, a, a + 0.10)
        o.location.z = o['base_z'] + 0.03 * (1 - spring(t, 8.0, 6.0))
        o['ghost'] = 1.0 - smoother(t / 0.35)
        o.hide_render = o['ghost'] > 0.97


def _drop(root, p, a, b, height):
    t = win(p, a, b)
    root.location.z = height * (1 - spring(t, 8.0, 6.0))
    gh = 1.0 - smoother(t / 0.3)
    for o in descendants(root):
        o['ghost'] = gh
        o.hide_render = gh > 0.97


def main():
    o = args()
    t0 = time.time()
    h, cam = build()
    rx, ry = (int(v) for v in o['res'].split('x'))
    desk.render_settings(o['samples'], (rx, ry))
    apply(o['p'], h, cam)
    bpy.context.view_layer.update()
    print(f'[maquette] build {time.time() - t0:.1f}s trees={len(h["trees"])} hinges={len(h["hinges"])}', flush=True)
    if o['blend']:
        bpy.ops.wm.save_as_mainfile(filepath=o['blend'])
    if o['out']:
        bpy.context.scene.render.filepath = o['out']
        t1 = time.time()
        bpy.ops.render.render(write_still=True)
        print(f'[maquette] render {time.time() - t1:.1f}s -> {o["out"]}', flush=True)


if __name__ == '__main__':
    main()
