"""1:100 card model of the villa: foam-board walls (from walls.json, hinged so they fold up out of the print),
greyboard slabs / white furniture / card roofs from the shared GLB, classic twig + foam model trees."""
import json
import math
import random
import bpy
import bmesh
from mathutils import Matrix, Vector
import mq

SHARED = mq.SHARED
S = 0.01                      # 1:100
CX, CY = 16.0, 15.0           # plan point placed at world origin
SLAB = 0.15


def to_world(x, y):
    """plan metres -> world metres (rotated 180 deg so the street faces -Y, the camera side)."""
    return Vector((-(x - CX) * S, (y - CY) * S, 0.0))


def link(ob, parent=None):
    bpy.context.collection.objects.link(ob)
    if parent is not None:
        ob.parent = parent
    return ob


def empty(name, parent=None, loc=(0, 0, 0)):
    e = link(bpy.data.objects.new(name, None), parent)
    e.location = loc
    e.empty_display_size = 0.01
    return e


def _box(bm, x0, x1, y0, y1, z0, z1):
    r = bmesh.ops.create_cube(bm, size=1.0)
    bmesh.ops.scale(bm, vec=(x1 - x0, y1 - y0, z1 - z0), verts=r['verts'])
    bmesh.ops.translate(bm, vec=((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), verts=r['verts'])


def build_wall(w, openings, height, foam, card, acetate, parent, centre):
    a, b = to_world(*w['start']), to_world(*w['end'])
    L = (b - a).length
    t = w['thickness_m'] * S
    rail = w['kind'] == 'railing'
    if rail:
        t = 0.0008
    ext = t / 2 if w['kind'] == 'loadBearing' else 0.0
    h = height * S
    d = (b - a).normalized()
    nrm = Vector((-d.y, d.x, 0))
    mid = (a + b) / 2
    outward = 1.0 if (mid - centre).dot(nrm) > 0 else -1.0
    # hinge on the outer bottom edge
    hinge = empty('hinge_' + w['id'], parent)
    hinge.location = a + nrm * outward * t / 2
    hinge.rotation_euler.z = math.atan2(d.y, d.x)
    hinge['fold_sign'] = -outward   # +90 deg about X lays a wall towards local -Y
    bm = bmesh.new()
    cuts = sorted(((o['along_m'] * S - o['width_m'] * S / 2, o['along_m'] * S + o['width_m'] * S / 2,
                    o['sill_m'] * S, o['head_m'] * S, o['type']) for o in openings), key=lambda c: c[0])
    x = -ext
    panes = []
    for c0, c1, sill, head, kind in cuts:
        if c0 > x:
            _box(bm, x, c0, -t / 2, t / 2, 0, h)
        if sill > 0:
            _box(bm, c0, c1, -t / 2, t / 2, 0, sill)
        if head < h:
            _box(bm, c0, c1, -t / 2, t / 2, min(head, h), h)
        if kind == 'window':
            panes.append((c0, c1, sill, min(head, h)))
        x = max(x, c1)
    if x < L + ext:
        _box(bm, x, L + ext, -t / 2, t / 2, 0, h)
    ob = mq.obj_from_bm('wall_' + w['id'], bm, card if rail else foam)
    ob['half_t'] = t / 2
    ob.parent = hinge
    # mesh is centred on its own y=0; hinge sits on the outer face, so shift the mesh back inwards
    ob.location = (0, -outward * t / 2, 0)
    mq.add_bevel(ob, min(0.00018, t * 0.12), 1, 40)
    if panes:
        pb = bmesh.new()
        for c0, c1, z0, z1 in panes:
            _box(pb, c0, c1, -0.00012, 0.00012, z0, z1)
        p = mq.obj_from_bm('pane_' + w['id'], pb, acetate)
        p.parent = hinge
        p.location = ob.location
    return hinge


def build_walls(foam, card, acetate, roots):
    data = json.load(open(SHARED + 'walls.json', encoding='utf8'))
    hinges = []
    for L in data['levels']:
        lvl = L['index']
        xs = [p for w in L['walls'] for p in (w['start'][0], w['end'][0])]
        ys = [p for w in L['walls'] for p in (w['start'][1], w['end'][1])]
        centre = to_world((min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2)
        top = lvl < len(data['levels']) - 1
        for w in L['walls']:
            ops = [o for o in L['openings'] if o['wall'] == w['id']]
            h = w['height_m'] if w['kind'] == 'railing' else (w['height_m'] - (SLAB if top else 0.0))
            hg = build_wall(w, ops, h, foam, card, acetate, roots[lvl], centre)
            hg.location.z = L['elevation_m'] * S
            hg['level'] = lvl
            hg['z0'] = hg.location.z
            hg['h'] = h * S
            hinges.append(hg)
    return hinges


def import_glb(mats, roots, roof_root):
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=SHARED + 'house.glb')
    new = set(bpy.data.objects) - before
    get = bpy.data.objects.get

    def subtree(name):
        o = get(name)
        if o is None:
            return []
        out, st = [], [o]
        while st:
            x = st.pop()
            out.append(x)
            st += list(x.children)
        return out

    keep = {}
    for lvl in range(3):
        for grp, m in (('slabs', 'grey'), ('furniture', 'white'), ('stair', 'white')):
            for o in subtree(f'level_{lvl}_{grp}'):
                keep[o] = (m, roots[lvl])
    for o in subtree('roofs'):
        keep[o] = ('roof', roof_root)
    plants = []
    for o in subtree('site:planting')[1:]:
        if o.parent and o.parent.name == 'site:planting':
            plants.append(o)
    plant_info = []
    for p in plants:
        lo, hi = Vector((1e9,) * 3), Vector((-1e9,) * 3)
        for x in subtree(p.name):
            if x.type == 'MESH':
                for c in x.bound_box:
                    wv = x.matrix_world @ Vector(c)
                    lo = Vector(map(min, lo, wv))
                    hi = Vector(map(max, hi, wv))
        if lo.x < 1e8:
            plant_info.append(((lo + hi) / 2, hi - lo))
    # bake world transforms, re-parent the kept meshes under our level roots
    for o, (m, root) in keep.items():
        if o.type != 'MESH':
            continue
        mw = o.matrix_world.copy()
        o.parent = None
        o.data = o.data.copy()
        o.data.transform(mw)
        o.matrix_world.identity()
        # glTF-in-Blender (X=x, Y=-y) -> our world
        o.data.transform(_glb_to_world())
        o.data.materials.clear()
        o.data.materials.append(mats[m])
        for poly in o.data.polygons:
            poly.use_smooth = False
        o.parent = root
        o.matrix_parent_inverse.identity()
        o.location = (0, 0, 0)
        o['kind'] = m
    for o in new:
        if o not in keep or keep[o] is None or o.type != 'MESH':
            bpy.data.objects.remove(o, do_unlink=True)
    return plant_info


def _glb_to_world():
    from mathutils import Matrix
    return Matrix.Translation((CX * S, -CY * S, 0)) @ Matrix.Rotation(math.pi, 4, 'Z') @ Matrix.Scale(S, 4)


# ---------------------------------------------------------------- model trees
def tree_variant(i, foam_mat, twig_mat, rng):
    """One classic model tree, ~1 unit tall (scaled per instance): twig trunk + branches, foam clumps."""
    root = bpy.data.objects.new(f'treeproto{i}', None)
    bpy.context.collection.objects.link(root)
    cu = bpy.data.curves.new(f'twig{i}', 'CURVE')
    cu.dimensions = '3D'
    cu.bevel_depth = 1.0
    cu.bevel_resolution = 3
    tips = []

    def spline(pts):
        sp = cu.splines.new('POLY')
        sp.points.add(len(pts) - 1)
        for p, (co, r) in zip(sp.points, pts):
            p.co = (*co, 1)
            p.radius = r
    trunk = [((0, 0, 0), 0.026), ((0.01, 0.0, 0.25), 0.021), ((-0.01, 0.01, 0.5), 0.016), ((0.0, 0.0, 0.72), 0.011)]
    spline(trunk)
    for k in range(5):
        ang = k / 5 * 2 * math.pi + rng.uniform(-0.4, 0.4)
        z0 = rng.uniform(0.35, 0.6)
        r = rng.uniform(0.18, 0.3)
        mid = (math.cos(ang) * r * 0.5, math.sin(ang) * r * 0.5, z0 + 0.12)
        tip = (math.cos(ang) * r, math.sin(ang) * r, z0 + rng.uniform(0.22, 0.35))
        spline([((0, 0, z0), 0.014), (mid, 0.009), (tip, 0.005)])
        tips.append(Vector(tip))
    tips.append(Vector((0, 0, 0.85)))
    tw = bpy.data.objects.new(f'twig{i}', cu)
    bpy.context.collection.objects.link(tw)
    tw.data.materials.append(twig_mat)
    tw.parent = root
    bm = bmesh.new()
    for tip in tips:
        for _ in range(14):
            c = tip + Vector((rng.uniform(-0.12, 0.12), rng.uniform(-0.12, 0.12), rng.uniform(-0.08, 0.09)))
            r = min(0.11, 0.022 * math.exp(rng.gauss(0.6, 0.45)))   # mixed sizes, mostly small
            res = bmesh.ops.create_icosphere(bm, subdivisions=3, radius=r)
            bmesh.ops.scale(bm, vec=(rng.uniform(0.7, 1.3), rng.uniform(0.7, 1.3), rng.uniform(0.55, 0.95)),
                            verts=res['verts'])
            bmesh.ops.rotate(bm, verts=res['verts'], cent=(0, 0, 0),
                             matrix=Matrix.Rotation(rng.uniform(0, 6.28), 3, Vector((rng.random(), rng.random(), 1))))
            bmesh.ops.translate(bm, vec=c, verts=res['verts'])
    fo = mq.obj_from_bm(f'foam{i}', bm, foam_mat, smooth=True)
    tex = bpy.data.textures.new(f'foamnoise{i}', 'CLOUDS')
    tex.noise_scale = 0.016
    tex.noise_depth = 3
    dm = fo.modifiers.new('lumps', 'DISPLACE')
    dm.texture = tex
    dm.strength = 0.05
    fine = bpy.data.textures.new(f'foamfine{i}', 'CLOUDS')
    fine.noise_scale = 0.005
    d2 = fo.modifiers.new('pores', 'DISPLACE')
    d2.texture = fine
    d2.strength = 0.012
    dm.mid_level = 0.5
    fo.parent = root
    return root


def svg_trees():
    import re
    svg = open(SHARED + 'plan-site.svg', encoding='utf8').read()
    out = []
    for m in re.finditer(r'<circle cx="([\d.]+)" cy="([\d.]+)" r="([\d.]+)"', svg):
        x, y, r = (float(v) / 1000 for v in m.groups())
        if r >= 0.5:
            out.append((x, y, r))
    return out


def build_trees(plant_info, parent):
    rng = random.Random(7)
    white = mq.mat_foam_tree('foam_white', (0.80, 0.79, 0.74))
    sage = mq.mat_foam_tree('foam_sage', (0.56, 0.62, 0.50))
    twig = mq.mat_twig()
    protos = [tree_variant(i, white if i % 2 == 0 else sage, twig, rng) for i in range(4)]
    colls = []
    for i, p in enumerate(protos):
        coll = bpy.data.collections.new(f'tree_proto{i}')   # not linked to the scene: instanced only
        for o in [p] + list(p.children):
            for c in list(o.users_collection):
                c.objects.unlink(o)
            coll.objects.link(o)
        colls.append(coll)
    trees = []
    for k, (x, y, r) in enumerate(svg_trees()):
        if k % 10 in (2, 5, 8):   # ~30% fewer than the print shows
            continue
        inst = bpy.data.objects.new(f'tree{k}', None)
        inst.instance_type = 'COLLECTION'
        inst.instance_collection = colls[k % 4]
        bpy.context.collection.objects.link(inst)
        inst.parent = parent
        sc = r * S / 0.36
        bush = r < 1.0
        inst.scale = (sc, sc, sc * (0.55 if bush else rng.uniform(0.9, 1.15)))
        w = to_world(x, y)
        inst.location = (w.x, w.y, -0.5 * sc if bush else 0.0)
        inst.rotation_euler.z = rng.uniform(0, 6.28)
        inst['base_z'] = inst.location.z
        trees.append(inst)
    return trees


def build_house(base_z):
    foam = bpy.data.materials.get('foamboard') or mq.mat_foamboard()
    card = mq.mat_card('wall_card', (0.80, 0.785, 0.745))
    mats = {
        'grey': mq.mat_greyboard(),
        'white': mq.mat_card('furniture_card', (0.82, 0.81, 0.775)),
        'roof': mq.mat_card('roof_card', (0.64, 0.615, 0.58)),
    }
    acetate = mq.mat_acetate()
    model = empty('model', loc=(0, 0, base_z))
    roots = [empty(f'level{i}', model) for i in range(3)]
    roof_root = empty('roof', model)
    tree_root = empty('trees', model)
    plant_info = import_glb(mats, roots, roof_root)
    hinges = build_walls(foam, card, acetate, roots)
    trees = build_trees(plant_info, tree_root)
    return {'model': model, 'levels': roots, 'roof': roof_root, 'hinges': hinges, 'trees': trees}
