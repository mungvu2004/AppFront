"""Combo chapters 3-5 for A: C's print on the sheet, a 50-frame intro (sheet fills the frame -> A's frame 0),
then A's 200-frame move. Frame n: 0..49 intro, 50..249 = A p (n-50)/199.

blender -b -P combo.py -- render --a 0 --b 30 [--samples 160]   frames -> F:/App-review/homepage-v6/maquette/combo-seq/
blender -b -P combo.py -- contracts                              a-registration.json + a-anchors.json
blender -b -P combo.py -- still --n 0 --out x.jpg [--samples 64 --res 960x540]
"""
import json
import math
import os
import sys
import time
import bpy
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector

sys.path.insert(0, os.path.dirname(__file__))
import build   # noqa: E402
import desk    # noqa: E402
import house   # noqa: E402
import mq      # noqa: E402

COMBO = mq.SHARED + 'combo/'
OUT = os.path.join(os.environ.get('KIT_OUT') or (os.path.join(mq.KIT, 'out') if mq.IN_KIT else
                                                 'F:/App-review/homepage-v6/maquette/combo-seq'), '')

INTRO, MAIN = 50, 200
N = INTRO + MAIN


def print_view():
    """print-plan.json -> (x0, y0, w, h) of the PNG in plan metres (x east, y into the plot, image y down)."""
    j = json.load(open(COMBO + 'print-plan.json', encoding='utf8'))
    if 'plan_window_m' in j:
        w = j['plan_window_m']
        return (w['x0'], w['y0'], w['w'], w['h'])
    if 'viewBox_m' in j:
        return tuple(j['viewBox_m'])
    if 'viewBox_mm' in j:
        return tuple(v / 1000 for v in j['viewBox_mm'])
    x0, y0 = j['origin_m']
    return (x0, y0, j['png_px'][0] / j['px_per_m'], j['png_px'][1] / j['px_per_m'])


VIEW = print_view()
PLAN_CENTRE = house.to_world(VIEW[0] + VIEW[2] / 2, VIEW[1] + VIEW[3] / 2)
# plan width = 70% of the frame width (50 mm lens, 36 mm sensor: frame width = 0.72 x distance); at this distance the
# 16:9 frame stays inside the A2 sheet, so only paper is visible.
_d = VIEW[2] * house.S / 0.72 / 0.70
# C's drawing is upright with the street at the top; A's frame 0 looks at the sheet from the street side (the model's
# 3/4 end view needs that), i.e. upside down. The intro starts upright and turns the sheet 180 deg under the camera
# while it pulls back (az 90 -> -87), still almost top-down, so C's match cut needs no rotation.
CAMI = dict(target=PLAN_CENTRE.copy(), dist=_d, elev=89.5, az=90.0, focal=50.0, shift=0.0, fstop=8.0,
            focus=PLAN_CENTRE.copy())


def frame(n, h, cam):
    if n < INTRO:
        q = n / INTRO
        build.apply(0.0, h, cam)
        # pull back + tilt: distance and shift ease in-out, the tilt starts a touch later so the first frames read flat
        s = build.smoother(q)
        build.pose(cam, *build.lerp_cam(CAMI, build.CAM0, s, se=build.smoother(build.win(q, 0.15, 1.0))))
    else:
        build.apply((n - INTRO) / (MAIN - 1), h, cam)


def scene():
    h, cam = build.build(COMBO + 'print-plan.png', VIEW, pencil=True)
    return h, cam


def px(cam, co):
    sc = bpy.context.scene
    v = world_to_camera_view(sc, cam, co)
    return [round(v.x * 1920, 1), round((1 - v.y) * 1080, 1)]


def contracts(h, cam):
    sc = bpy.context.scene
    sc.render.resolution_x, sc.render.resolution_y = 1920, 1080
    frame(0, h, cam)
    bpy.context.view_layer.update()
    z = bpy.data.objects['paper'].location.z + 0.00025
    x0, y0, w, hh = VIEW
    img = [house.to_world(x, y) + Vector((0, 0, z)) for x, y in ((x0, y0), (x0 + w, y0), (x0 + w, y0 + hh), (x0, y0 + hh))]
    walls = [house.to_world(x, y) + Vector((0, 0, z)) for x, y in ((4, 9), (28, 9), (28, 21), (4, 21))]
    ip = [px(cam, c) for c in img]
    wp = [px(cam, c) for c in walls]
    ang = math.degrees(math.atan2(ip[1][1] - ip[0][1], ip[1][0] - ip[0][0]))

    def rect(pts):
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        return {'x': min(xs), 'y': min(ys), 'w': round(max(xs) - min(xs), 1), 'h': round(max(ys) - min(ys), 1)}
    reg = {
        'frame': 'intro frame 0 = combo/a/1920/0000.webp, 1920x1080 px, y down',
        'print_png_corners_px': {'top_left': ip[0], 'top_right': ip[1], 'bottom_right': ip[2], 'bottom_left': ip[3]},
        'print_png_rect_px': rect(ip),
        'print_rotation_deg': round(ang, 3),
        'print_png_meaning': 'corners of print-plan.png (its full extent, VIEW %s m) as printed on A\'s sheet' % (VIEW,),
        'exterior_walls_bbox_plan_m': [4, 9, 28, 21],
        'exterior_walls_corners_px': wp,
        'note': 'Camera is 0.5 deg off nadir (no keystone worth noting); C can place its drawing with an affine map '
                'from print-plan.png px to these corners.',
    }
    json.dump(reg, open(COMBO + 'a-registration.json', 'w'), indent=1)
    # floor label anchors: the slab corner of each level that ends up right-most on screen, at slab top
    data = json.load(open(house.SHARED + 'walls.json', encoding='utf8'))
    corners = {}
    for L in data['levels']:
        xs = [v for w in L['walls'] if w['kind'] == 'loadBearing' for v in (w['start'][0], w['end'][0])]
        ys = [v for w in L['walls'] if w['kind'] == 'loadBearing' for v in (w['start'][1], w['end'][1])]
        corners[L['index']] = (L['elevation_m'], [(x, y) for x in (min(xs), max(xs)) for y in (min(ys), max(ys))])
    frame(N - 1, h, cam)
    bpy.context.view_layer.update()
    pick = {}
    for lvl, (el, cs) in corners.items():
        pts = [house.to_world(x, y) + Vector((0, 0, el * house.S + h['model'].location.z)) for x, y in cs]
        pick[lvl] = max(range(4), key=lambda i: px(cam, pts[i])[0])
    out = {'frame': '1920x1080 px, y down; index = combo frame number (0000.webp ...)', 'levels': {}, 'frames': []}
    for lvl, (el, cs) in corners.items():
        out['levels'][str(lvl)] = {'name': f'Tầng {lvl + 1}', 'corner_plan_m': cs[pick[lvl]], 'slab_top_m': el}
    for n in range(N):
        frame(n, h, cam)
        bpy.context.view_layer.update()
        row = {'n': n}
        for lvl, (el, cs) in corners.items():
            root = h['levels'][lvl]
            offs = root.location.z
            x, y = cs[pick[lvl]]
            co = house.to_world(x, y) + Vector((0, 0, h['model'].location.z + el * house.S + offs))
            hidden = any(o.hide_render for o in root.children if o.type == 'MESH') if lvl else False
            row[str(lvl)] = {'px': px(cam, co), 'apart_m_at_1to1': round(offs / house.S, 3),
                             'visible': not hidden}
        out['frames'].append(row)
    json.dump(out, open(COMBO + 'a-anchors.json', 'w'), indent=0)
    print('[combo] contracts written', reg['print_png_rect_px'], reg['print_rotation_deg'])


def render(a, b, samples):
    os.makedirs(OUT, exist_ok=True)
    web = os.path.join(OUT, '1920', '') if mq.IN_KIT else 'F:/worktrees/AppFront/homepage-v6/public/landing-lab/combo/a/1920/'
    if not mq.IN_KIT and not os.environ.get('KIT_ALL'):
        b = min(b, INTRO)   # local RTX: intro only, Colab renders the rest
    todo = [n for n in range(a, min(b, N)) if not (os.path.exists(f'{OUT}{n:04d}.jpg') or os.path.exists(f'{web}{n:04d}.webp'))]
    if not todo:
        return
    h, cam = scene()
    desk.render_settings(samples, (1920, 1080))
    bpy.context.scene.render.image_settings.quality = 95
    for n in todo:
        t = time.time()
        frame(n, h, cam)
        bpy.context.view_layer.update()
        bpy.context.scene.render.filepath = f'{OUT}{n:04d}.jpg'
        bpy.ops.render.render(write_still=True)
        print(f'[combo] {n:04d} {time.time() - t:.1f}s', flush=True)


def main():
    a = sys.argv[sys.argv.index('--') + 1:]
    cmd, o = a[0], dict(zip((k.lstrip('-') for k in a[1::2]), a[2::2]))
    if cmd == 'render':
        render(int(o['a']), int(o['b']), int(o.get('samples', 160)))
    elif cmd == 'contracts':
        contracts(*scene())
    elif cmd == 'still':
        h, cam = scene()
        rx, ry = (int(v) for v in o.get('res', '1920x1080').split('x'))
        desk.render_settings(int(o.get('samples', 64)), (rx, ry))
        frame(int(o['n']), h, cam)
        bpy.context.view_layer.update()
        bpy.context.scene.render.filepath = o['out']
        bpy.ops.render.render(write_still=True)


main()
