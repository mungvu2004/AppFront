"""Desk, cutting mat, paper, props, sun through a window, world + render settings."""
import math
import os
import bpy
import bmesh
from mathutils import Vector, Matrix
import mq

MAT_TOP = 0.003            # cutting mat top (m)
PAPER_W, PAPER_H = 0.594, 0.42  # A2 landscape
PAPER_Z = MAT_TOP + 0.0002
SUN_DIR = Vector((-0.62, -0.66, 0.42)).normalized()  # from scene towards the sun (front-left, ~25 deg)


def desk():
    bm = bmesh.new()
    bmesh.ops.create_grid(bm, x_segments=1, y_segments=1, size=1.0)
    bmesh.ops.scale(bm, vec=(2.4, 1.52, 1), verts=bm.verts)
    ob = mq.obj_from_bm('desk', bm, mq.mat_wood())
    ob.location = (-0.1, -0.04, 0)
    # the desk stands against a warm plaster wall with a low bright window behind the model (seen only out of focus)
    wall = mq.box('back_wall', 6.0, 0.05, 3.0, mq.mat_card('plaster', (0.80, 0.72, 0.62)), loc=(0, 0.765, 1.5))
    wall.visible_shadow = False
    glow = mq.box('window_glow', 1.3, 0.01, 1.2, None, loc=(-0.45, 0.735, 0.62))
    gm = bpy.data.materials.new('window_glow')
    n = mq.NT(gm)
    em = n.node('ShaderNodeEmission')
    em.inputs['Color'].default_value = (1.0, 0.90, 0.78, 1)
    em.inputs['Strength'].default_value = 9.0
    n.link(em.outputs[0], n.out.inputs[0])
    glow.data.materials.append(gm)
    glow.visible_shadow = False
    glow.visible_diffuse = False   # camera-only: a glow in the bokeh, not a second key light
    glow.visible_glossy = False
    glow.visible_transmission = False
    return ob


def cutting_mat():
    ob = mq.box('cutting_mat', 0.90, 0.60, MAT_TOP, mq.mat_mat(), bevel=0.0012, segs=3, angle=60)
    ob.location = (0.04, 0.03, MAT_TOP / 2)
    ob.rotation_euler.z = math.radians(-2.5)
    return ob


def paper(img_path, pencil=False):
    """A2 sheet, plan centred at object origin. Corner (+x,+y) curls up; whole sheet has a faint wave."""
    bm = bmesh.new()
    nx, ny = 150, 106
    bmesh.ops.create_grid(bm, x_segments=nx, y_segments=ny, size=0.5)
    bmesh.ops.scale(bm, vec=(PAPER_W, PAPER_H, 1), verts=bm.verts)
    uv = bm.loops.layers.uv.new('UVMap')
    for f in bm.faces:
        for lp in f.loops:
            x, y, _ = lp.vert.co
            lp[uv].uv = (x / PAPER_W + 0.5, y / PAPER_H + 0.5)
    corner = Vector((PAPER_W / 2, PAPER_H / 2, 0))
    axis = Vector((-1, -1, 0)).normalized()
    for v in bm.verts:
        d = (v.co - corner).dot(axis)          # distance from corner along the diagonal
        lift = max(0.0, 0.075 - d)              # last 7.5 cm curl
        v.co.z = 0.009 * (lift / 0.075) ** 2.2 + 0.0004 * math.sin(v.co.x * 17 + 1.3) * math.sin(v.co.y * 11)
        v.co.z = max(v.co.z, 0.0)
    ob = mq.obj_from_bm('paper', bm, mq.mat_paper(img_path, 'paper_plan', pencil), smooth=True)
    sol = ob.modifiers.new('thick', 'SOLIDIFY')
    sol.thickness = 0.00025
    sol.offset = 1.0
    ob.location = (0, 0, PAPER_Z - 0.00012)
    return ob


def pencil():
    root = bpy.data.objects.new('pencil', None)
    bpy.context.collection.objects.link(root)
    chrome = mq.mat_metal('chrome', (0.9, 0.9, 0.9), 0.12)
    body_m = mq.mat_metal('anodised_graphite', (0.16, 0.17, 0.19), 0.38, aniso=0.6)
    rubber = mq.mat_knurl('rubber_grip', (0.018, 0.018, 0.02), 0.0, 0.7, pitch=0.0011)
    lead = mq.mat_plain('lead', (0.03, 0.03, 0.035), 0.35, 0.6)
    parts = [
        mq.lathe('pencil_lead', [(0.0, -0.0008), (0.00025, -0.0007), (0.00025, 0.0005)], 16, lead),
        mq.lathe('pencil_pipe', [(0.00026, 0.0), (0.00045, 0.0), (0.00045, 0.004), (0.0009, 0.0042),
                                 (0.0014, 0.007), (0.0024, 0.012), (0.0034, 0.016), (0.0038, 0.0185),
                                 (0.0038, 0.0195)], 48, chrome),
        mq.lathe('pencil_grip', [(0.0037, 0.0195), (0.0042, 0.020), (0.0043, 0.022), (0.0043, 0.050),
                                 (0.0042, 0.052), (0.0037, 0.0525)], 64, rubber),
    ]
    body = mq.lathe('pencil_body', [(0.0037, 0.0525), (0.0042, 0.053), (0.0042, 0.133), (0.0038, 0.1335)], 6,
                    body_m, smooth=False)
    mq.add_bevel(body, 0.0006, 3, 50)
    parts.append(body)
    parts.append(mq.lathe('pencil_cap', [(0.0033, 0.133), (0.0034, 0.1345), (0.0034, 0.141), (0.0030, 0.1435),
                                         (0.0018, 0.1448), (0.0, 0.145)], 48, chrome))
    clip = mq.box('pencil_clip', 0.0022, 0.0009, 0.045, chrome, bevel=0.0003, segs=2)
    clip.location = (0, 0.0047, 0.112)
    parts.append(clip)
    for p in parts:
        p.parent = root
    for p in parts[:3] + parts[4:]:
        for poly in p.data.polygons:
            poly.use_smooth = True
    return root


def ruler():
    L, W, T = 0.32, 0.028, 0.0009
    ob = mq.box('ruler', L, W, T, None, bevel=0.0002, segs=2, angle=30)
    m = bpy.data.materials.new('ruler_steel')
    n = mq.NT(m)
    co = n.coord('Object')
    x, y, z = n.sep(co)
    u = n.math('ADD', x, L / 2 - 0.01)  # 0 mark 1 cm from the left end
    edge = n.math('SUBTRACT', W / 2, y)  # distance from the +y edge
    mm = mq.line_mask(n, u, 0.001, 0.00007)
    half = mq.line_mask(n, u, 0.005, 0.00008)
    cm = mq.line_mask(n, u, 0.01, 0.00009)
    tick_len = n.math('MAXIMUM', n.math('MULTIPLY', mm, 0.0025),
                      n.math('MAXIMUM', n.math('MULTIPLY', half, 0.004), n.math('MULTIPLY', cm, 0.0055)))
    tick = n.math('LESS_THAN', edge, tick_len)
    inrange = n.math('MULTIPLY', n.math('GREATER_THAN', u, -0.0002), n.math('LESS_THAN', u, 0.3002))
    top = n.math('GREATER_THAN', z, T / 2 - 0.0001)
    ink = n.math('MULTIPLY', n.math('MULTIPLY', tick, inrange), top)
    br = n.noise(n.mapping(co, scale=(6, 4000, 6)), 1.0, 3, 0.5)
    col = n.mix(ink, (0.62, 0.62, 0.63), (0.02, 0.02, 0.022))
    n.bsdf(**{'Base Color': col, 'Metallic': n.math('SUBTRACT', 1.0, ink),
              'Roughness': n.math('ADD', n.math('ADD', 0.22, n.math('MULTIPLY', ink, 0.45)),
                                  n.math('MULTIPLY', br.outputs[0], 0.08)),
              'Anisotropic': 0.7, 'Normal': n.bump(br.outputs[0], 0.05, 0.00002)})
    ob.data.materials.append(m)
    ink_m = mq.mat_plain('ruler_ink', (0.02, 0.02, 0.022), 0.6)
    for i in range(0, 31):
        cu = bpy.data.curves.new(f'rnum{i}', 'FONT')
        cu.body = str(i)
        cu.size = 0.0032
        cu.align_x = 'CENTER'
        t = bpy.data.objects.new(f'rnum{i}', cu)
        bpy.context.collection.objects.link(t)
        t.data.materials.append(ink_m)
        t.parent = ob
        t.location = (-L / 2 + 0.01 + i * 0.01, W / 2 - 0.0095, T / 2 + 0.00002)
    return ob


def knife():
    root = bpy.data.objects.new('knife', None)
    bpy.context.collection.objects.link(root)
    alu = mq.mat_knurl('alu_knurl', (0.78, 0.79, 0.8), 1.0, 0.3, pitch=0.0009)
    alu_s = mq.mat_metal('alu_smooth', (0.8, 0.8, 0.82), 0.25, aniso=0.5)
    blade_m = mq.mat_metal('blade', (0.72, 0.73, 0.75), 0.18, aniso=0.8)
    parts = [
        mq.lathe('knife_chuck', [(0.0012, -0.002), (0.0024, -0.001), (0.0034, 0.004), (0.0040, 0.014),
                                 (0.0042, 0.018), (0.0042, 0.020)], 48, alu_s),
        mq.lathe('knife_grip', [(0.0042, 0.020), (0.0046, 0.0205), (0.0046, 0.072), (0.0044, 0.073)], 64, alu),
        mq.lathe('knife_tail', [(0.0044, 0.073), (0.0044, 0.110), (0.0040, 0.118), (0.0025, 0.1225),
                                (0.0, 0.1235)], 48, alu_s),
    ]
    bm = bmesh.new()
    pts = [(-0.0032, -0.0015), (0.0032, -0.0015), (0.0032, -0.022), (0.0, -0.042), (-0.0032, -0.016)]
    vs = [bm.verts.new((x, 0, z)) for x, z in pts]
    f = bm.faces.new(vs)
    ext = bmesh.ops.extrude_face_region(bm, geom=[f])
    bmesh.ops.translate(bm, vec=(0, 0.0004, 0), verts=[e for e in ext['geom'] if isinstance(e, bmesh.types.BMVert)])
    bmesh.ops.translate(bm, vec=(0, -0.0002, 0), verts=bm.verts)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    blade = mq.obj_from_bm('knife_blade', bm, blade_m)
    mq.add_bevel(blade, 0.00008, 2, 30)
    parts.append(blade)
    for p in parts:
        p.parent = root
    return root


def offcuts(foam, card):
    obs = []
    for i, (lx, w, x, y, rz) in enumerate([(0.07, 0.006, 0.36, -0.17, 12), (0.045, 0.0045, 0.395, -0.145, -21),
                                           (0.03, 0.008, 0.33, -0.20, 64)]):
        ob = mq.box(f'offcut{i}', lx, 0.003, w, foam, bevel=0.0001, segs=1)
        ob['half_t'] = 0.0015
        ob.rotation_euler = (math.radians(90), 0, math.radians(rz))
        ob.location = (x, y, MAT_TOP + 0.0015)
        obs.append(ob)
    bm = bmesh.new()
    vs = [bm.verts.new(p) for p in [(0, 0, 0), (0.05, 0.004, 0), (0.012, 0.028, 0)]]
    bm.faces.new(vs)
    tri = mq.obj_from_bm('offcut_card', bm, card)
    s = tri.modifiers.new('t', 'SOLIDIFY')
    s.thickness = 0.0006
    tri.location = (0.31, -0.235, MAT_TOP + 0.0001)
    tri.rotation_euler.z = math.radians(-8)
    obs.append(tri)
    return obs


def place(ob, loc, heading, lay=True, roll=0.0):
    """Lathe props run along local Z: roll about that axis, lay it along X, then turn by heading."""
    from mathutils import Quaternion
    q = Quaternion((0, 0, 1), heading)
    if lay:
        q = q @ Quaternion((0, 1, 0), math.radians(90))
    ob.rotation_mode = 'QUATERNION'
    ob.rotation_quaternion = q @ Quaternion((0, 0, 1), roll)
    ob.location = loc


def window_gobo():
    """Wall with a 2x3 paned window, perpendicular to the sun, invisible to camera: casts the frame shadow."""
    bm = bmesh.new()
    # one big window, one mullion (its soft bar crosses the model), the transom high so its bar lands off-scene
    W, H, frame, mull = 2.4, 1.9, 0.08, 0.035
    bars = [(0, H / 2 - frame / 2, W, frame), (0, -H / 2 + frame / 2, W, frame),
            (-W / 2 + frame / 2, 0, frame, H), (W / 2 - frame / 2, 0, frame, H),
            (0, 0, mull, H), (0, 0.62, W, mull)]
    for cx, cy, sx, sy in bars:
        r = bmesh.ops.create_cube(bm, size=1.0)
        bmesh.ops.scale(bm, vec=(sx, sy, 0.05), verts=r['verts'])
        bmesh.ops.translate(bm, vec=(cx, cy, 0), verts=r['verts'])
    # surrounding wall (four slabs around the opening)
    for cx, cy, sx, sy in [(0, H / 2 + 1.5, 6, 3), (0, -H / 2 - 1.5, 6, 3), (-W / 2 - 1.5, 0, 3, H), (W / 2 + 1.5, 0, 3, H)]:
        r = bmesh.ops.create_cube(bm, size=1.0)
        bmesh.ops.scale(bm, vec=(sx, sy, 0.05), verts=r['verts'])
        bmesh.ops.translate(bm, vec=(cx, cy, 0), verts=r['verts'])
    ob = mq.obj_from_bm('window_gobo', bm, mq.mat_plain('gobo', (0.2, 0.2, 0.2), 0.9))
    # orient: plane normal (local Z) along the sun direction, centred on the ray through the model
    rot = SUN_DIR.to_track_quat('Z', 'Y')
    ob.rotation_mode = 'QUATERNION'
    ob.rotation_quaternion = rot
    ob.location = Vector((0.03, -0.01, 0.07)) + SUN_DIR * 2.6
    ob.visible_camera = False
    ob.visible_glossy = False
    ob.visible_diffuse = False
    return ob


def lights_world(sun_strength=5.5, world_strength=0.32):
    sun = bpy.data.lights.new('sun', 'SUN')
    sun.energy = sun_strength
    sun.angle = math.radians(0.8)
    sun.color = (1.0, 0.80, 0.60)
    ob = bpy.data.objects.new('sun', sun)
    bpy.context.collection.objects.link(ob)
    ob.rotation_mode = 'QUATERNION'
    ob.rotation_quaternion = (-SUN_DIR).to_track_quat('-Z', 'Y')
    w = bpy.data.worlds.new('studio')
    bpy.context.scene.world = w
    w.use_nodes = True
    t = w.node_tree
    t.nodes.clear()
    tc = t.nodes.new('ShaderNodeTexCoord')
    mp = t.nodes.new('ShaderNodeMapping')
    mp.inputs['Rotation'].default_value = (0, 0, math.radians(200))
    env = t.nodes.new('ShaderNodeTexEnvironment')
    env.image = bpy.data.images.load(mq.ASSETS + 'art_studio_2k.hdr')
    bg = t.nodes.new('ShaderNodeBackground')
    bg.inputs['Strength'].default_value = world_strength
    hsv = t.nodes.new('ShaderNodeHueSaturation')
    hsv.inputs['Saturation'].default_value = 0.6
    out = t.nodes.new('ShaderNodeOutputWorld')
    t.links.new(tc.outputs['Generated'], mp.inputs['Vector'])
    t.links.new(mp.outputs[0], env.inputs['Vector'])
    t.links.new(env.outputs[0], hsv.inputs['Color'])
    warm = t.nodes.new('ShaderNodeMix')
    warm.data_type = 'RGBA'
    warm.blend_type = 'MULTIPLY'
    warm.inputs[0].default_value = 1.0
    warm.inputs[7].default_value = (1.0, 0.92, 0.82, 1)
    t.links.new(hsv.outputs[0], warm.inputs[6])
    t.links.new(warm.outputs[2], bg.inputs['Color'])
    t.links.new(bg.outputs[0], out.inputs['Surface'])
    return ob


def render_settings(samples=256, res=(1920, 1080)):
    sc = bpy.context.scene
    sc.render.engine = 'CYCLES'
    prefs = bpy.context.preferences.addons['cycles'].preferences
    # KIT_DEVICE=CPU forces CPU; otherwise OptiX, falling back to CUDA, then CPU.
    want = os.environ.get('KIT_DEVICE', 'GPU').upper()
    kind = None
    if want != 'CPU':
        for k in ('OPTIX', 'CUDA'):
            try:
                prefs.compute_device_type = k
            except TypeError:
                continue
            prefs.get_devices()
            if any(d.type == k for d in prefs.devices):
                kind = k
                break
    for d in prefs.devices:
        d.use = d.type == kind
    sc.cycles.device = 'GPU' if kind else 'CPU'
    print(f'[render] device {kind or "CPU"}', flush=True)
    sc.cycles.samples = samples
    sc.cycles.use_adaptive_sampling = True
    sc.cycles.adaptive_threshold = 0.012
    sc.cycles.use_denoising = True
    sc.cycles.denoiser = 'OPENIMAGEDENOISE'
    sc.cycles.denoising_use_gpu = kind is not None
    sc.cycles.max_bounces = 8
    sc.cycles.diffuse_bounces = 6
    sc.cycles.transmission_bounces = 6
    sc.cycles.transparent_max_bounces = 64   # ghosted fade-ins stack many layers; too few bounces renders black
    sc.cycles.caustics_reflective = False
    sc.cycles.caustics_refractive = False
    sc.cycles.blur_glossy = 1.0
    sc.render.resolution_x, sc.render.resolution_y = res
    sc.render.resolution_percentage = 100
    sc.view_settings.view_transform = 'AgX'
    sc.view_settings.look = 'AgX - Medium High Contrast'
    sc.view_settings.exposure = 0.35
    sc.render.image_settings.file_format = 'JPEG'
    sc.render.image_settings.quality = 92
    sc.render.film_transparent = False


def build_desk(plan_png, pencil_print=False):
    desk()
    cutting_mat()
    paper(plan_png, pencil_print)
    pen = pencil()
    place(pen, (0.30, -0.245, MAT_TOP + 0.0037), math.radians(-14), roll=math.radians(30))
    r = ruler()
    place(r, (0.10, 0.248, MAT_TOP + 0.00045), math.radians(1.5), lay=False)
    k = knife()
    place(k, (0.40, -0.02, MAT_TOP + 0.0046), math.radians(78), roll=math.radians(90))
    foam = bpy.data.materials.get('foamboard') or mq.mat_foamboard()
    offcuts(foam, mq.mat_card('offcut_card', (0.80, 0.78, 0.74)))
    window_gobo()
    lights_world()
