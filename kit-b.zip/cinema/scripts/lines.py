# Blueprint line pass: same camera, flat deep-blue fill, white Freestyle lines; plants/grass/lights hidden.
import bpy

BG = (0.0060, 0.0215, 0.0560)  # linear ~ #0E2847 (sRGB)
INK = (0.86, 0.92, 1.0)


def setup(sc, res):
    sc.render.engine = "CYCLES"
    sc.cycles.device = "CPU"
    sc.cycles.samples = 1
    sc.cycles.use_denoising = False
    sc.render.resolution_x, sc.render.resolution_y = res
    sc.render.resolution_percentage = 100
    sc.view_settings.view_transform = "Standard"
    sc.view_settings.look = "None"
    sc.render.film_transparent = False
    sc.render.image_settings.file_format = "PNG"
    sc.render.image_settings.color_mode = "RGB"
    sc.render.image_settings.compression = 60
    w = sc.world
    w.node_tree.nodes.clear()
    out = w.node_tree.nodes.new("ShaderNodeOutputWorld")
    bg = w.node_tree.nodes.new("ShaderNodeBackground")
    bg.inputs["Color"].default_value = (*BG, 1)
    w.node_tree.links.new(bg.outputs[0], out.inputs[0])
    fill = bpy.data.materials.new("BlueprintFill")
    fill.use_nodes = True
    nt = fill.node_tree
    nt.nodes.clear()
    em = nt.nodes.new("ShaderNodeEmission")
    em.inputs["Color"].default_value = (*BG, 1)
    o = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(em.outputs[0], o.inputs[0])
    vl = sc.view_layers[0]
    vl.material_override = fill
    for name in ("VEG", "LIGHTS", "INTERIOR"):
        lc = vl.layer_collection.children.get(name)
        if lc:
            lc.exclude = True
    for ob in sc.objects:
        if ob.type == "LIGHT":
            ob.hide_render = True
        for m in ob.modifiers:
            if m.type == "NODES":
                m.show_render = False
        n = ob.name
        if ob.get("grp") in ("roofs", "level_1", "level_2") or any(k in n for k in ("soffitLights", "koi", "lotus", "I-CAR", "I-BAY", "sill_", "plinth_", "neigh_", "prop_", "gutter_", "ceiling_")):
            for c in [ob, *ob.children_recursive]:
                c.hide_render = True
    sc.render.use_freestyle = True
    sc.render.line_thickness_mode = "ABSOLUTE"
    sc.render.line_thickness = 1.0
    vl.use_freestyle = True
    fs = vl.freestyle_settings
    fs.crease_angle = 2.35  # ~135 deg
    fs.use_culling = True
    for ls in list(fs.linesets):
        fs.linesets.remove(ls)
    heavy = bpy.data.collections.get("LN_HEAVY")
    # Hierarchy: walls + site boundary heavy, everything else (furniture, paving, plants beds) light.
    for name, neg, thick, alpha in (("structure", "INCLUSIVE", 2.3, 1.0), ("detail", "EXCLUSIVE", 0.9, 0.72)):
        ls = fs.linesets.new(name)
        ls.select_by_visibility = True
        ls.visibility = "VISIBLE"
        ls.select_by_edge_types = True
        ls.select_silhouette = True
        ls.select_border = True
        ls.select_crease = True
        ls.select_external_contour = True
        ls.select_by_collection = True
        ls.collection = heavy
        ls.collection_negation = neg
        st = ls.linestyle
        st.color = INK
        st.alpha = alpha
        st.thickness = thick
        st.chaining = "PLAIN"
        st.caps = "ROUND"
