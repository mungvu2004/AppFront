# Interior dressing for the walk-in (combo chapter 6): hall G1, dining G3, living G2 at exterior quality.
# Blender coords: x = plan x, y = -plan y, z up, FFL 0.
import bpy, math, random
from mathutils import Vector

import lib

R = random.Random(11)


def _mat_fabric(name, color, bump=0.25, scale=180.0):
    m = bpy.data.materials.get(name)
    if m:
        return m
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    bs = nt.nodes["Principled BSDF"]
    tc = nt.nodes.new("ShaderNodeTexCoord")
    wv = nt.nodes.new("ShaderNodeTexWave")
    wv.inputs["Scale"].default_value = scale
    wv.inputs["Distortion"].default_value = 1.5
    nz = nt.nodes.new("ShaderNodeTexNoise")
    nz.inputs["Scale"].default_value = 6
    nt.links.new(tc.outputs["Object"], wv.inputs["Vector"])
    nt.links.new(tc.outputs["Object"], nz.inputs["Vector"])
    mix = nt.nodes.new("ShaderNodeMix")
    mix.data_type = "RGBA"
    mix.blend_type = "MULTIPLY"
    mix.inputs["Factor"].default_value = 0.18
    mix.inputs["A"].default_value = (*color, 1)
    nt.links.new(nz.outputs["Color"], mix.inputs["B"])
    nt.links.new(mix.outputs["Result"], bs.inputs["Base Color"])
    bp = nt.nodes.new("ShaderNodeBump")
    bp.inputs["Strength"].default_value = bump
    bp.inputs["Distance"].default_value = 0.002
    nt.links.new(wv.outputs["Fac"], bp.inputs["Height"])
    nt.links.new(bp.outputs["Normal"], bs.inputs["Normal"])
    bs.inputs["Roughness"].default_value = 0.9
    bs.inputs["Sheen Weight"].default_value = 0.4
    return m


def _mat_art(name, cols, seed):
    """Abstract painted canvas: warped noise through a colour ramp, brush-like bump."""
    m = bpy.data.materials.get(name)
    if m:
        return m
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    bs = nt.nodes["Principled BSDF"]
    tc = nt.nodes.new("ShaderNodeTexCoord")
    nz = nt.nodes.new("ShaderNodeTexNoise")
    nz.inputs["Scale"].default_value = 1.6
    nz.inputs["Detail"].default_value = 6
    nz.inputs["Distortion"].default_value = 2.5
    nz.noise_dimensions = "4D"
    nz.inputs["W"].default_value = seed
    nt.links.new(tc.outputs["Object"], nz.inputs["Vector"])
    cr = nt.nodes.new("ShaderNodeValToRGB")
    els = cr.color_ramp.elements
    els[0].position, els[0].color = 0.3, (*cols[0], 1)
    els[1].position, els[1].color = 0.7, (*cols[-1], 1)
    for i, c in enumerate(cols[1:-1]):
        e = els.new(0.4 + 0.2 * i / max(1, len(cols) - 3))
        e.color = (*c, 1)
    nt.links.new(nz.outputs["Fac"], cr.inputs["Fac"])
    nt.links.new(cr.outputs["Color"], bs.inputs["Base Color"])
    bp = nt.nodes.new("ShaderNodeBump")
    bp.inputs["Strength"].default_value = 0.35
    nt.links.new(nz.outputs["Fac"], bp.inputs["Height"])
    nt.links.new(bp.outputs["Normal"], bs.inputs["Normal"])
    bs.inputs["Roughness"].default_value = 0.75
    return m


def _sheer():
    m = bpy.data.materials.get("Sheer")
    if m:
        return m
    m = bpy.data.materials.new("Sheer")
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    tl = nt.nodes.new("ShaderNodeBsdfTranslucent")
    tl.inputs["Color"].default_value = (0.95, 0.9, 0.82, 1)
    df = nt.nodes.new("ShaderNodeBsdfDiffuse")
    df.inputs["Color"].default_value = (0.9, 0.86, 0.8, 1)
    tr = nt.nodes.new("ShaderNodeBsdfTransparent")
    m1 = nt.nodes.new("ShaderNodeMixShader")
    m1.inputs["Fac"].default_value = 0.5
    nt.links.new(df.outputs[0], m1.inputs[1])
    nt.links.new(tl.outputs[0], m1.inputs[2])
    m2 = nt.nodes.new("ShaderNodeMixShader")
    m2.inputs["Fac"].default_value = 0.45  # 45 % of light passes straight through
    nt.links.new(m1.outputs[0], m2.inputs[1])
    nt.links.new(tr.outputs[0], m2.inputs[2])
    nt.links.new(m2.outputs[0], out.inputs["Surface"])
    return m


def _link(col, o):
    for c in o.users_collection:
        c.objects.unlink(o)
    col.objects.link(o)
    return o


def _cube(col, name, mn, mx, mat, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(size=1, location=[(a + b) / 2 for a, b in zip(mn, mx)])
    o = bpy.context.object
    o.name = name
    o.scale = [b - a for a, b in zip(mn, mx)]
    bpy.ops.object.transform_apply(scale=True)
    if bevel:
        mod = o.modifiers.new("bev", "BEVEL")
        mod.width = bevel
        mod.segments = 2
    o.data.materials.append(mat)
    return _link(col, o)


def curtain(col, name, x0, x1, y, z0, z1, mat, folds=0.11, depth=0.05):
    """Sheer curtain along x at plan-facing y: a subdivided plane with sinusoidal folds."""
    nx = max(8, int((x1 - x0) / 0.02))
    verts, faces = [], []
    for i in range(nx + 1):
        x = x0 + (x1 - x0) * i / nx
        dy = depth * math.sin(x / folds * math.tau) + 0.4 * depth * math.sin(x / (folds * 2.7) * math.tau)
        verts += [(x, y + dy, z0), (x, y + dy, z1)]
        if i:
            a = 2 * (i - 1)
            faces.append((a, a + 2, a + 3, a + 1))
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    for p in me.polygons:
        p.use_smooth = True
    me.materials.append(mat)
    o = bpy.data.objects.new(name, me)
    col.objects.link(o)
    return o


def books(col, x, y, z, along_x, n, rot=0.0):
    """A row/stack of books: n slim boxes with varied sizes and muted cloth colours."""
    palette = [(0.42, 0.18, 0.12), (0.12, 0.2, 0.26), (0.55, 0.47, 0.35), (0.16, 0.24, 0.17), (0.6, 0.56, 0.5), (0.25, 0.2, 0.16)]
    off = 0.0
    for i in range(n):
        t = R.uniform(0.025, 0.05)
        h = R.uniform(0.18, 0.27)
        d = R.uniform(0.13, 0.17)
        m = lib.simple(f"Book{i % len(palette)}", palette[i % len(palette)], rough=0.7)
        if along_x:
            _cube(col, "prop_book", (x + off, y - d / 2, z), (x + off + t, y + d / 2, z + h), m)
        else:
            _cube(col, "prop_book", (x - d / 2, y + off, z), (x + d / 2, y + off + t, z + h), m)
        off += t + 0.002


def stack(col, x, y, z, n):
    zz = z
    for i in range(n):
        w, d, t = R.uniform(0.22, 0.3), R.uniform(0.16, 0.22), R.uniform(0.025, 0.04)
        c = [(0.85, 0.82, 0.76), (0.2, 0.22, 0.25), (0.55, 0.3, 0.2), (0.7, 0.66, 0.58)][i % 4]
        _cube(col, "prop_book", (x - w / 2, y - d / 2, zz), (x + w / 2, y + d / 2, zz + t), lib.simple(f"Cover{i % 4}", c, rough=0.6))
        zz += t
    return zz


def remat_furniture(house_col, M):
    fabric = _mat_fabric("Linen", (0.62, 0.56, 0.47))
    cushion = _mat_fabric("LinenLight", (0.74, 0.69, 0.6))
    pillow = _mat_fabric("Terracotta", (0.55, 0.26, 0.15), scale=120)
    wool = _mat_fabric("Wool", (0.66, 0.6, 0.52), bump=0.5, scale=60)
    wool_dark = _mat_fabric("WoolDark", (0.2, 0.17, 0.14), bump=0.5, scale=60)
    walnut = lib.pbr("Walnut", "japanese_cedar_planks", size_m=1.0, sat=0.6, val=0.42, bump=0.2, rough_mul=0.7)
    oak = lib.pbr("OakStair", "wood_floor", size_m=1.2, sat=0.85, val=0.95, bump=0.15, rough_mul=0.7)
    screen = lib.simple("Screen", (0.005, 0.005, 0.006), rough=0.06)
    brass = lib.simple("Brass", (0.75, 0.55, 0.28), rough=0.3, metal=1.0)
    shade = lib.simple("ShadeLinen", (0.92, 0.86, 0.76), rough=0.8, emission=(1.0, 0.7, 0.42), strength=3)
    pendant = lib.simple("PendantGlow", (0.95, 0.9, 0.8), rough=0.4, emission=(1.0, 0.68, 0.38), strength=8)
    table = {
        "slot_body.001": fabric, "slot_cushion": cushion, "slot_pillow": pillow, "slot_top": walnut,
        "slot_legs": M["metal"], "slot_a": wool_dark, "slot_b": wool, "slot_frame": screen, "slot_screen": screen,
        "slot_body.005": walnut, "slot_shelf": walnut, "slot_shade": shade, "slot_drawers": walnut, "slot_handle": brass,
        "slot_body": walnut, "slot_cabinet": walnut, "Material.005": pendant, "wood": oak,
    }
    for o in list(bpy.data.objects):
        if o is None or o.type != "MESH":
            continue
        for s in o.material_slots:
            if not s.material:
                continue
            base = s.material.name
            key = base if base in table else base.rsplit(".", 1)[0]
            if base.startswith("slot_legs"):
                key = "slot_legs"
            new = table.get(key)
            if new:
                s.link = "OBJECT" if o.data.users > 1 else "DATA"
                s.material = new
    # Pascal low-poly indoor plants: hide, real ones are placed instead.
    for o in list(bpy.data.objects):
        if o.type == "MESH" and any(sl.material and sl.material.name.startswith(("slot_foliage", "slot_trunk", "slot_soil", "slot_pot")) for sl in o.material_slots):
            o.hide_render = True


def lights(col):
    def spot(x, y, energy=55, z=3.17, disc=True):
        ld = bpy.data.lights.new("downlight", "SPOT")
        ld.energy = energy
        ld.color = (1.0, 0.8, 0.62)
        ld.spot_size = math.radians(80)
        ld.spot_blend = 0.6
        ld.shadow_soft_size = 0.04
        lo = bpy.data.objects.new("downlight", ld)
        lo.location = (x, y, z)
        col.objects.link(lo)
        if not disc:
            return
        # The visible fitting: a small glowing disc flush with the ceiling (slab underside z 3.225).
        bpy.ops.mesh.primitive_cylinder_add(radius=0.045, depth=0.01, location=(x, y, 3.21))
        d = bpy.context.object
        d.name = "prop_downlight"
        d.data.materials.append(lib.simple("DownlightGlow", (1, 1, 1), emission=(1.0, 0.78, 0.55), strength=30))
        _link(col, d)

    for x in (11.0, 12.6):
        for y in (-10.2, -12.0, -13.8):
            spot(x, y, 35)
    for x in (10.5, 14.5):
        for y in (-16.5, -19.5):
            spot(x, y, 40)
    for x in (17.5, 20.0, 22.5):
        for y in (-16.3, -19.7):
            spot(x, y, 45)
    for x in (24.5, 27.0):  # under the single-storey roof: ceiling is higher, lights a bit stronger
        for y in (-16.3, -19.7):
            spot(x, y, 55, z=3.17)
    # Floor lamp G2 (22.9, -20.3) and dining pendants (12.1/13.1, -18).
    for (x, y, z, e) in ((22.9, -20.3, 1.45, 45), (12.1, -18.0, 2.2, 25), (13.1, -18.0, 2.2, 25)):
        ld = bpy.data.lights.new("lamp", "POINT")
        ld.energy = e
        ld.color = (1.0, 0.76, 0.52)
        ld.shadow_soft_size = 0.1
        lo = bpy.data.objects.new("lamp", ld)
        lo.location = (x, y, z)
        col.objects.link(lo)


def ceilings(M):
    """Slab undersides and the roof's underside are ceilings: warm plaster, not floor boards or roof metal."""
    for o in list(bpy.data.objects):
        if o.type != "MESH" or o.data.users != 1:
            continue
        if not (o.name.startswith("slab_") or o.name in ("RF1", "RF2", "RF3")):
            continue
        o.data.materials.append(M["plaster"])
        k = len(o.data.materials) - 1
        for p in o.data.polygons:
            if p.normal.z < -0.5:
                p.material_index = k


def dress(sc, house_col, M, place):
    ceilings(M)
    # The single-storey east wing (x 22-28) has only the roof above: give it a flat plaster ceiling.
    _cube(bpy.data.collections["HOUSE"], "ceiling_east", (22.0, -21.0, 3.225), (28.0, -9.0, 3.26), M["plaster"])
    col = bpy.data.collections.new("INTERIOR")
    sc.collection.children.link(col)
    remat_furniture(house_col, M)
    lights(bpy.data.collections["LIGHTS"])
    sheer = _sheer()
    # Sheer curtains on the living (SL1, plan x 17-27) and dining (SL2, x 10-15) glass walls, pulled into soft
    # gathered panels at both ends and a light sheer across.
    for x0, x1 in ((17.0, 18.4), (25.6, 27.0), (10.0, 11.0), (14.0, 15.0)):
        curtain(col, "prop_curtain", x0, x1, -20.72, 0.02, 3.15, sheer, folds=0.09, depth=0.06)
    curtain(col, "prop_curtain", 18.4, 21.2, -20.62, 0.02, 3.15, sheer, folds=0.16, depth=0.035)
    # Art: a large canvas on the living room's south wall (plan y 15), one in the hall, one in dining.
    frame = lib.simple("FrameOak", (0.36, 0.25, 0.15), rough=0.5)
    for name, (x0, x1, y, z0, z1), cols, seed in (
        ("art_living", (23.6, 26.4, -15.08, 1.05, 2.45), [(0.82, 0.74, 0.6), (0.62, 0.36, 0.2), (0.25, 0.27, 0.24), (0.9, 0.86, 0.78)], 3.0),
        ("art_dining", (9.08, 9.12, -17.0, 1.2, 2.2), [(0.2, 0.26, 0.3), (0.72, 0.65, 0.52), (0.85, 0.8, 0.7)], 7.0),
    ):
        if name == "art_living":
            _cube(col, "prop_" + name + "_frame", (x0 - 0.03, y - 0.04, z0 - 0.03), (x1 + 0.03, y + 0.005, z1 + 0.03), frame)
            _cube(col, "prop_" + name, (x0, y - 0.045, z0), (x1, y - 0.035, z1), _mat_art(name, cols, seed))
        else:
            _cube(col, "prop_" + name + "_frame", (9.06, -20.45, z0 - 0.03), (9.1, -18.75, z1 + 0.03), frame)
            _cube(col, "prop_" + name, (9.1, -20.4, z0), (9.11, -18.8, z1), _mat_art(name, cols, seed))
    # Books and objects: coffee table (24.8, -18), console in the hall, a reading stack by the sofa.
    top = 0.295
    books(col, 10.3, -12.55, 0.728, False, 14)
    place("potted_plant_04", 10.4, -13.4, 1.1, z=0.728)
    # Sideboard in the dining room gets books and a bowl.
    books(col, 9.33, -19.9, 0.728, False, 10)
    # Real plants: by the door, beside the stair, living corners, dining corner.
    place("potted_plant_01", 10.6, -9.6, 1.25, z=0.0)
    place("potted_plant_01", 27.35, -20.35, 1.45, z=0.0)
    place("potted_plant_02", 17.4, -20.3, 1.6, z=0.0)
    place("potted_plant_01", 15.4, -20.4, 1.3, z=0.0)
    place("calathea_orbifolia_01", 21.4, -20.2, 1.0, z=0.0)
    place("calathea_orbifolia_01", 16.6, -15.6, 1.0, z=0.0)
    living(col, house_col, place)
    return col


def _hide_pascal_living(house_col):
    keep = ("wall_", "slab_", "window_", "folded", "door_", "prop_", "v_", "site", "RF", "sill_", "plinth", "gutter", "Mesh347")
    for o in list(bpy.data.objects):
        if o.type != "MESH" or o.name.startswith(keep):
            continue
        bb = [o.matrix_world @ Vector(c) for c in o.bound_box]
        cx, cy, z0 = sum(p.x for p in bb) / 8, sum(p.y for p in bb) / 8, min(p.z for p in bb)
        if 16.1 < cx < 27.95 and -20.95 < cy < -15.05 and -0.1 < z0 < 2.5:
            o.hide_render = True


def _rug(col, x0, y0, x1, y1):
    m = _mat_fabric("RugWool", (0.5, 0.45, 0.38), bump=1.2, scale=70)
    o = _cube(col, "prop_rug_living", (x0, y0, 0.0), (x1, y1, 0.018), m, bevel=0.008)
    return o


def living(col, house_col, place):
    """Hero vignette: real Poly Haven sofa, lounge chair, coffee/side table, cabinet, plants, books, rug."""
    _hide_pascal_living(house_col)
    _rug(col, 22.4, -19.7, 25.6, -16.7)
    place("sofa_02", 22.85, -18.2, 1.25, z=0.0, rot=math.radians(90))
    place("throw_pillows_01", 22.85, -17.5, 0.8, z=0.43, rot=math.radians(90))
    place("modern_coffee_table_01", 24.3, -18.2, 1.15, z=0.0, rot=0.0)
    place("mid_century_lounge_chair", 25.9, -19.55, 1.0, z=0.0, rot=math.radians(-115))
    place("side_table_01", 22.7, -19.95, 1.0, z=0.0, rot=0.0)
    place("ceramic_vase_01", 22.7, -19.95, 1.0, z=0.55)
    place("modern_wooden_cabinet", 19.4, -15.35, 1.0, z=0.0, rot=0.0)
    books(col, 18.55, -15.35, 0.68, True, 18)
    place("ceramic_vase_03", 20.2, -15.35, 1.0, z=0.68)
    place("potted_plant_04", 20.55, -15.35, 1.0, z=0.68)
    z = stack(col, 24.15, -17.95, 0.39, 3)
    place("ceramic_vase_03", 24.45, -18.55, 0.8, z=0.39)
    place("potted_plant_02", 26.9, -16.0, 1.5, z=0.0)
    # A low golden "sun" raking in through the rear glazing (only for the interior walk; off for exterior paths).
    ld = bpy.data.lights.new("fake_sun", "SPOT")
    ld.energy = 9000
    ld.color = (1.0, 0.7, 0.42)
    ld.spot_size = math.radians(28)
    ld.spot_blend = 0.3
    ld.shadow_soft_size = 0.15
    lo = bpy.data.objects.new("fake_sun", ld)
    lo.location = (12.5, -33.0, 5.2)
    lo.rotation_euler = (Vector((23.5, -18.5, 0.0)) - lo.location).to_track_quat("-Z", "Y").to_euler()
    lo.hide_render = True  # switched on by cam_int
    bpy.data.collections["LIGHTS"].objects.link(lo)
