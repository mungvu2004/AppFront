# Combo interior walk: starts exactly at the cinema sequence's last frame (b_119) and goes through the door,
# past the floating stair, across the dining room, and settles on the living-room vignette.
import cam_combo as cc

cc.KEYS[:] = [
    (0.00, (6.5, -1.3, 1.2), (14.5, -9.0, 2.5), 26.0, 0.0, 0.0),
    (0.14, (11.6, -5.2, 1.45), (13.3, -10.8, 1.55), 24.0, 0.0, 0.1),
    (0.26, (13.2, -8.7, 1.5), (13.3, -14.0, 1.5), 22.0, 0.0, 0.0),
    (0.38, (13.0, -11.0, 1.55), (15.6, -12.9, 1.9), 22.0, 0.0, 0.0),
    (0.48, (11.7, -13.4, 1.5), (12.0, -18.0, 1.4), 22.0, 0.0, 0.0),
    (0.58, (12.6, -16.0, 1.5), (20.0, -18.0, 1.3), 23.0, 0.0, 0.0),
    (0.68, (17.0, -17.2, 1.45), (23.5, -18.8, 0.9), 24.0, 0.0, 0.0),
    (0.78, (21.5, -16.6, 1.42), (24.5, -19.0, 0.8), 24.0, 0.0, 0.0),
    (0.88, (24.3, -16.35, 1.5), (22.0, -19.4, 0.75), 25.0, 0.0, 0.0),
    (1.00, (27.2, -16.2, 1.55), (21.0, -19.6, 0.7), 26.0, 0.0, 0.0),
]
at = cc.at


def set_cam(cam, p, scene=None):
    import bpy
    cc.set_cam(cam, p, scene)
    sun = bpy.data.objects.get("fake_sun")
    if sun:
        sun.hide_render = False
    cam.data.dof.aperture_fstop = 4.0  # same as the cinema frames it continues from
