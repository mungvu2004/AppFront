# Shared helpers for the cinema scene: render setup, world/sun, PBR materials, grass.
import bpy, bmesh, math, os, random
from mathutils import Vector

ROOT = "F:/App-review/homepage-v6/cinema"
TEX = f"{ROOT}/assets/tex"
HDRI = f"{ROOT}/assets/hdri"

# HDRI sun position measured by sun.py (u = equirect x fraction, elev deg).
HDRI_SUN = {"kloppenheim_06_puresky": (0.612, 4.6), "belfast_sunset_puresky": (0.605, 2.1), "spruit_sunrise": (0.599, 8.0)}


def setup_render(scene, samples=256, res=(1920, 1080), gpu=True):
    scene.render.engine = "CYCLES"
    c = scene.cycles
    if gpu:
        prefs = bpy.context.preferences.addons["cycles"].preferences
        prefs.compute_device_type = "OPTIX"
        prefs.get_devices()
        for d in prefs.devices:
            d.use = d.type == "OPTIX"
        c.device = "GPU"
    c.samples = samples
    c.use_adaptive_sampling = True
    c.adaptive_threshold = 0.02
    c.use_denoising = True
    c.denoiser = "OPENIMAGEDENOISE"
    c.denoising_input_passes = "RGB_ALBEDO_NORMAL"
    c.denoising_prefilter = "ACCURATE"
    c.max_bounces = 8
    c.diffuse_bounces = 3
    c.glossy_bounces = 3
    c.transmission_bounces = 8
    c.transparent_max_bounces = 16
    c.caustics_reflective = False
    c.caustics_refractive = False
    c.sample_clamp_indirect = 8
    c.blur_glossy = 1.0
    scene.render.resolution_x, scene.render.resolution_y = res
    scene.render.resolution_percentage = 100
    scene.view_settings.view_transform = "AgX"
    scene.view_settings.look = "AgX - Medium High Contrast"
    scene.render.film_transparent = False


def setup_world(scene, hdri="kloppenheim_06_puresky", strength=1.0, sun_az_deg=235.0, sun_strength=4.0, sun_color=(1.0, 0.72, 0.45), sun_elev=None):
    """World HDRI rotated so its sun sits at azimuth sun_az_deg (0 = +X, ccw), plus a matching Sun lamp."""
    w = scene.world or bpy.data.worlds.new("World")
    scene.world = w
    w.use_nodes = True
    nt = w.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputWorld")
    bg = nt.nodes.new("ShaderNodeBackground")
    env = nt.nodes.new("ShaderNodeTexEnvironment")
    env.image = bpy.data.images.load(f"{HDRI}/{hdri}_4k.hdr", check_existing=True)
    mp = nt.nodes.new("ShaderNodeMapping")
    tc = nt.nodes.new("ShaderNodeTexCoord")
    u, elev = HDRI_SUN[hdri]
    # Blender equirect: direction azimuth a = atan2(y, x) maps to u = -a/(2pi) + 0.5.
    hdri_az = (0.5 - u) * 360.0
    mp.inputs["Rotation"].default_value[2] = math.radians(hdri_az - sun_az_deg)
    nt.links.new(tc.outputs["Generated"], mp.inputs["Vector"])
    nt.links.new(mp.outputs["Vector"], env.inputs["Vector"])
    nt.links.new(env.outputs["Color"], bg.inputs["Color"])
    bg.inputs["Strength"].default_value = strength
    nt.links.new(bg.outputs["Background"], out.inputs["Surface"])
    sun = bpy.data.objects.get("Sun")
    if not sun:
        sun = bpy.data.objects.new("Sun", bpy.data.lights.new("Sun", "SUN"))
        scene.collection.objects.link(sun)
    sun.data.energy = sun_strength
    sun.data.color = sun_color
    sun.data.angle = math.radians(1.2)
    e = sun_elev if sun_elev is not None else max(elev, 6.0)
    az = math.radians(sun_az_deg)
    d = Vector((math.cos(az) * math.cos(math.radians(e)), math.sin(az) * math.cos(math.radians(e)), math.sin(math.radians(e))))
    sun.rotation_euler = (-d).to_track_quat("-Z", "Y").to_euler()
    return sun


def _img(path, colour):
    im = bpy.data.images.load(path, check_existing=True)
    if not colour:
        im.colorspace_settings.name = "Non-Color"
    return im


def pbr(name, tex_id, size_m=2.0, tint=None, rough_mul=1.0, bump=0.4, disp=0.0, sat=1.0, val=1.0, flat=None, flat_mix=0.0, vary=0.0):
    """Principled material from a Poly Haven texture folder, box-projected in object space (metres)."""
    m = bpy.data.materials.get(name)
    if m:
        return m
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    d = f"{TEX}/{tex_id}"
    files = {f.split(tex_id + "_")[1].rsplit("_", 1)[0]: f"{d}/{f}" for f in os.listdir(d)}
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    bs = nt.nodes.new("ShaderNodeBsdfPrincipled")
    tc = nt.nodes.new("ShaderNodeTexCoord")
    mp = nt.nodes.new("ShaderNodeMapping")
    mp.inputs["Scale"].default_value = (1 / size_m,) * 3
    nt.links.new(tc.outputs["Object"], mp.inputs["Vector"])

    def tex(key, colour):
        t = nt.nodes.new("ShaderNodeTexImage")
        t.image = _img(files[key], colour)
        t.projection = "BOX"
        t.projection_blend = 0.25
        nt.links.new(mp.outputs["Vector"], t.inputs["Vector"])
        return t

    diff = tex("diff", True)
    col = diff.outputs["Color"]
    hsv = nt.nodes.new("ShaderNodeHueSaturation")
    hsv.inputs["Saturation"].default_value = sat
    hsv.inputs["Value"].default_value = val
    nt.links.new(col, hsv.inputs["Color"])
    col = hsv.outputs["Color"]
    if flat:
        fm = nt.nodes.new("ShaderNodeMix")
        fm.data_type = "RGBA"
        fm.inputs["Factor"].default_value = flat_mix
        fm.inputs["B"].default_value = (*flat, 1)
        nt.links.new(col, fm.inputs["A"])
        col = fm.outputs["Result"]
    if tint:
        mix = nt.nodes.new("ShaderNodeMix")
        mix.data_type = "RGBA"
        mix.blend_type = "MULTIPLY"
        mix.inputs["Factor"].default_value = 1.0
        mix.inputs["B"].default_value = (*tint, 1)
        nt.links.new(col, mix.inputs["A"])
        col = mix.outputs["Result"]
    if vary:
        nz = nt.nodes.new("ShaderNodeTexNoise")
        nz.inputs["Scale"].default_value = 0.06
        nz.inputs["Detail"].default_value = 4
        nt.links.new(tc.outputs["Object"], nz.inputs["Vector"])
        mr = nt.nodes.new("ShaderNodeMapRange")
        mr.inputs["From Min"].default_value = 0.35
        mr.inputs["From Max"].default_value = 0.65
        mr.inputs["To Min"].default_value = 1 - vary
        mr.inputs["To Max"].default_value = 1 + vary * 0.4
        nt.links.new(nz.outputs["Fac"], mr.inputs["Value"])
        vm = nt.nodes.new("ShaderNodeMix")
        vm.data_type = "RGBA"
        vm.blend_type = "MULTIPLY"
        vm.inputs["Factor"].default_value = 1.0
        cc = nt.nodes.new("ShaderNodeCombineColor")
        for i in range(3):
            nt.links.new(mr.outputs["Result"], cc.inputs[i])
        nt.links.new(col, vm.inputs["A"])
        nt.links.new(cc.outputs["Color"], vm.inputs["B"])
        col = vm.outputs["Result"]
    if "ao" in files:
        ao = tex("ao", False)
        mix = nt.nodes.new("ShaderNodeMix")
        mix.data_type = "RGBA"
        mix.blend_type = "MULTIPLY"
        mix.inputs["Factor"].default_value = 0.6
        nt.links.new(col, mix.inputs["A"])
        nt.links.new(ao.outputs["Color"], mix.inputs["B"])
        col = mix.outputs["Result"]
    nt.links.new(col, bs.inputs["Base Color"])
    if "rough" in files:
        r = tex("rough", False)
        mm = nt.nodes.new("ShaderNodeMath")
        mm.operation = "MULTIPLY"
        mm.use_clamp = True
        mm.inputs[1].default_value = rough_mul
        nt.links.new(r.outputs["Color"], mm.inputs[0])
        nt.links.new(mm.outputs[0], bs.inputs["Roughness"])
    if "nor_gl" in files:
        n = tex("nor_gl", False)
        nm = nt.nodes.new("ShaderNodeNormalMap")
        nm.inputs["Strength"].default_value = bump * 2
        nt.links.new(n.outputs["Color"], nm.inputs["Color"])
        nt.links.new(nm.outputs["Normal"], bs.inputs["Normal"])
    nt.links.new(bs.outputs["BSDF"], out.inputs["Surface"])
    if disp and "disp" in files:
        dt = tex("disp", False)
        dn = nt.nodes.new("ShaderNodeDisplacement")
        dn.inputs["Scale"].default_value = disp
        dn.inputs["Midlevel"].default_value = 0.5
        nt.links.new(dt.outputs["Color"], dn.inputs["Height"])
        nt.links.new(dn.outputs["Displacement"], out.inputs["Displacement"])
        m.displacement_method = "BUMP"
    return m


def simple(name, color, rough=0.5, metal=0.0, emission=None, strength=0.0, transmission=0.0, ior=1.45, alpha=1.0):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes = True
    bs = m.node_tree.nodes["Principled BSDF"]
    bs.inputs["Base Color"].default_value = (*color, 1)
    bs.inputs["Roughness"].default_value = rough
    bs.inputs["Metallic"].default_value = metal
    bs.inputs["Transmission Weight"].default_value = transmission
    bs.inputs["IOR"].default_value = ior
    bs.inputs["Alpha"].default_value = alpha
    if emission:
        bs.inputs["Emission Color"].default_value = (*emission, 1)
        bs.inputs["Emission Strength"].default_value = strength
    return m


def glass(name="Glass"):
    """Thin architectural glass: reflective, slightly green-grey, light passes (no refraction offset)."""
    m = bpy.data.materials.get(name)
    if m:
        return m
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    gl = nt.nodes.new("ShaderNodeBsdfGlossy")
    gl.inputs["Roughness"].default_value = 0.045
    gl.inputs["Color"].default_value = (1, 1, 1, 1)
    tr = nt.nodes.new("ShaderNodeBsdfTransparent")
    tr.inputs["Color"].default_value = (0.78, 0.82, 0.8, 1)
    fr = nt.nodes.new("ShaderNodeLayerWeight")
    fr.inputs["Blend"].default_value = 0.12
    mx = nt.nodes.new("ShaderNodeMixShader")
    # Fresnel-ish: ~8% reflect face-on, more at grazing.
    ramp = nt.nodes.new("ShaderNodeMath")
    ramp.operation = "MULTIPLY_ADD"
    ramp.inputs[1].default_value = 0.85
    ramp.inputs[2].default_value = 0.08
    nt.links.new(fr.outputs["Fresnel"], ramp.inputs[0])
    nt.links.new(ramp.outputs[0], mx.inputs["Fac"])
    nt.links.new(tr.outputs["BSDF"], mx.inputs[1])
    nt.links.new(gl.outputs["BSDF"], mx.inputs[2])
    nt.links.new(mx.outputs["Shader"], out.inputs["Surface"])
    return m


def grass_material():
    m = bpy.data.materials.get("GrassBlade")
    if m:
        return m
    m = bpy.data.materials.new("GrassBlade")
    m.use_nodes = True
    nt = m.node_tree
    bs = nt.nodes["Principled BSDF"]
    out = nt.nodes["Material Output"]
    oi = nt.nodes.new("ShaderNodeObjectInfo")
    att = nt.nodes.new("ShaderNodeAttribute")
    att.attribute_type = "INSTANCER"
    att.attribute_name = "rnd"
    ramp = nt.nodes.new("ShaderNodeValToRGB")
    els = ramp.color_ramp.elements
    els[0].color = (0.09, 0.15, 0.035, 1)
    els[1].color = (0.30, 0.30, 0.09, 1)
    e = els.new(0.5)
    e.color = (0.14, 0.21, 0.05, 1)
    nt.links.new(att.outputs["Fac"], ramp.inputs["Fac"])
    # Darker at the root (uv.y along blade).
    uv = nt.nodes.new("ShaderNodeUVMap")
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    nt.links.new(uv.outputs["UV"], sep.inputs["Vector"])
    pw = nt.nodes.new("ShaderNodeMath")
    pw.operation = "POWER"
    pw.inputs[1].default_value = 0.6
    nt.links.new(sep.outputs["Y"], pw.inputs[0])
    mul = nt.nodes.new("ShaderNodeMix")
    mul.data_type = "RGBA"
    mul.blend_type = "MULTIPLY"
    mul.inputs["Factor"].default_value = 1.0
    nt.links.new(ramp.outputs["Color"], mul.inputs["A"])
    lerp = nt.nodes.new("ShaderNodeMapRange")
    lerp.inputs["To Min"].default_value = 0.35
    nt.links.new(pw.outputs[0], lerp.inputs["Value"])
    comb = nt.nodes.new("ShaderNodeCombineColor")
    for i in range(3):
        nt.links.new(lerp.outputs["Result"], comb.inputs[i])
    nt.links.new(comb.outputs["Color"], mul.inputs["B"])
    nt.links.new(mul.outputs["Result"], bs.inputs["Base Color"])
    bs.inputs["Roughness"].default_value = 0.45
    bs.inputs["Specular IOR Level"].default_value = 0.35
    # Leaf translucency: mix in a translucent lobe.
    tl = nt.nodes.new("ShaderNodeBsdfTranslucent")
    nt.links.new(mul.outputs["Result"], tl.inputs["Color"])
    mx = nt.nodes.new("ShaderNodeMixShader")
    mx.inputs["Fac"].default_value = 0.3
    nt.links.new(bs.outputs["BSDF"], mx.inputs[1])
    nt.links.new(tl.outputs["BSDF"], mx.inputs[2])
    nt.links.new(mx.outputs["Shader"], out.inputs["Surface"])
    return m


def grass_patch(name="GrassPatch", size=0.5, blades=900, h=(0.05, 0.13), seed=1):
    """A square patch of curved tapered grass blades (3 segments each), UV.y = along blade."""
    if name in bpy.data.objects:
        return bpy.data.objects[name]
    rnd = random.Random(seed)
    bm = bmesh.new()
    uvl = bm.loops.layers.uv.new("UVMap")
    for _ in range(blades):
        x, y = rnd.uniform(-size / 2, size / 2), rnd.uniform(-size / 2, size / 2)
        hh = rnd.uniform(*h)
        wdt = rnd.uniform(0.0025, 0.0045)
        yaw = rnd.uniform(0, math.tau)
        lean = rnd.uniform(0.15, 0.7) * hh
        dx, dy = math.cos(yaw), math.sin(yaw)
        px, py = -dy, dx
        rows = []
        for i in range(4):
            t = i / 3
            off = lean * t * t
            cx, cy, cz = x + dx * off, y + dy * off, hh * t * (1 - 0.25 * t * t * lean / hh)
            ww = wdt * (1 - t) + 0.0004
            rows.append((bm.verts.new((cx - px * ww, cy - py * ww, cz)), bm.verts.new((cx + px * ww, cy + py * ww, cz)), t))
        for (a0, b0, t0), (a1, b1, t1) in zip(rows, rows[1:]):
            f = bm.faces.new((a0, b0, b1, a1))
            for l, uv in zip(f.loops, ((0, t0), (1, t0), (1, t1), (0, t1))):
                l[uvl].uv = uv
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    for p in me.polygons:
        p.use_smooth = True
    me.materials.append(grass_material())
    ob = bpy.data.objects.new(name, me)
    return ob


def grass_scatter(target, patch, density=7.0, name="GrassGN", holes=()):
    """Geometry nodes: Poisson-distribute grass patches on `target` faces (top-facing), random yaw/scale + rnd attr."""
    ng = bpy.data.node_groups.get(name)
    if not ng:
        ng = bpy.data.node_groups.new(name, "GeometryNodeTree")
        ng.interface.new_socket("Geometry", in_out="INPUT", socket_type="NodeSocketGeometry")
        ng.interface.new_socket("Geometry", in_out="OUTPUT", socket_type="NodeSocketGeometry")
        n = ng.nodes
        L = ng.links.new
        gi, go = n.new("NodeGroupInput"), n.new("NodeGroupOutput")
        dist = n.new("GeometryNodeDistributePointsOnFaces")
        dist.distribute_method = "RANDOM"
        dist.inputs["Density"].default_value = density
        nrm = n.new("GeometryNodeInputNormal")
        sep = n.new("ShaderNodeSeparateXYZ")
        cmp = n.new("FunctionNodeCompare")
        cmp.data_type = "FLOAT"
        cmp.operation = "GREATER_THAN"
        cmp.inputs[1].default_value = 0.7
        L(nrm.outputs["Normal"], sep.inputs["Vector"])
        L(sep.outputs["Z"], cmp.inputs[0])
        L(gi.outputs["Geometry"], dist.inputs["Mesh"])
        L(cmp.outputs["Result"], dist.inputs["Selection"])
        oi = n.new("GeometryNodeObjectInfo")
        oi.inputs["Object"].default_value = patch
        oi.transform_space = "ORIGINAL"
        inst = n.new("GeometryNodeInstanceOnPoints")
        pts = dist.outputs["Points"]
        if holes:
            # Drop grass patches inside hardscape boxes (x0, y0, x1, y1): paths, stepping stones.
            ppos = n.new("GeometryNodeInputPosition")
            psep = n.new("ShaderNodeSeparateXYZ")
            L(ppos.outputs["Position"], psep.inputs["Vector"])
            acc = None
            for x0, y0, x1, y1 in holes:
                parts = []
                for comp, lo, hi in (("X", x0, x1), ("Y", y0, y1)):
                    for op, v in (("GREATER_THAN", lo), ("LESS_THAN", hi)):
                        c = n.new("FunctionNodeCompare")
                        c.data_type = "FLOAT"
                        c.operation = op
                        c.inputs[1].default_value = v
                        L(psep.outputs[comp], c.inputs[0])
                        parts.append(c.outputs["Result"])
                a = parts[0]
                for b in parts[1:]:
                    bm_ = n.new("FunctionNodeBooleanMath")
                    bm_.operation = "AND"
                    L(a, bm_.inputs[0])
                    L(b, bm_.inputs[1])
                    a = bm_.outputs[0]
                if acc is None:
                    acc = a
                else:
                    o_ = n.new("FunctionNodeBooleanMath")
                    o_.operation = "OR"
                    L(acc, o_.inputs[0])
                    L(a, o_.inputs[1])
                    acc = o_.outputs[0]
            dg = n.new("GeometryNodeDeleteGeometry")
            dg.domain = "POINT"
            L(pts, dg.inputs["Geometry"])
            L(acc, dg.inputs["Selection"])
            pts = dg.outputs["Geometry"]
        L(pts, inst.inputs["Points"])
        L(oi.outputs["Geometry"], inst.inputs["Instance"])
        rr = n.new("FunctionNodeRandomValue")
        rr.data_type = "FLOAT"
        rr.inputs["Max"].default_value = math.tau
        crot = n.new("ShaderNodeCombineXYZ")
        L(rr.outputs["Value"], crot.inputs["Z"])
        L(crot.outputs["Vector"], inst.inputs["Rotation"])
        rs = n.new("FunctionNodeRandomValue")
        rs.data_type = "FLOAT"
        rs.inputs["Min"].default_value = 0.75
        rs.inputs["Max"].default_value = 1.3
        rs.inputs["Seed"].default_value = 7
        L(rs.outputs["Value"], inst.inputs["Scale"])
        # Per-patch colour variation, smooth-ish via noise on position plus jitter.
        pos = n.new("GeometryNodeInputPosition")
        noise = n.new("ShaderNodeTexNoise")
        noise.inputs["Scale"].default_value = 0.35
        noise.inputs["Detail"].default_value = 3
        L(pos.outputs["Position"], noise.inputs["Vector"])
        store = n.new("GeometryNodeStoreNamedAttribute")
        store.data_type = "FLOAT"
        store.domain = "INSTANCE"
        store.inputs["Name"].default_value = "rnd"
        L(inst.outputs["Instances"], store.inputs["Geometry"])
        L(noise.outputs["Fac"], store.inputs["Value"])
        join = n.new("GeometryNodeJoinGeometry")
        L(gi.outputs["Geometry"], join.inputs["Geometry"])
        L(store.outputs["Geometry"], join.inputs["Geometry"])
        L(join.outputs["Geometry"], go.inputs["Geometry"])
    mod = target.modifiers.new("grass", "NODES")
    mod.node_group = ng
    return mod


def ribbed(name, color, metal=0.8, rough=(0.3, 0.45), spacing=0.45, seam_w=0.02, bump=0.5, vary=0.12):
    """Procedural ribbed metal: ribs run down the slope (roofs) or vertically (walls), spaced along the
    horizontal tangent of the face, so a hip roof gets standing seams on every face without UVs."""
    m = bpy.data.materials.get(name)
    if m:
        return m
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    n, L = nt.nodes, nt.links.new
    bs = n["Principled BSDF"]
    geo = n.new("ShaderNodeNewGeometry")
    sep = n.new("ShaderNodeSeparateXYZ")
    L(geo.outputs["Normal"], sep.inputs["Vector"])
    tan = n.new("ShaderNodeCombineXYZ")
    neg = n.new("ShaderNodeMath")
    neg.operation = "MULTIPLY"
    neg.inputs[1].default_value = -1
    L(sep.outputs["Y"], neg.inputs[0])
    L(neg.outputs[0], tan.inputs["X"])
    L(sep.outputs["X"], tan.inputs["Y"])
    nrm = n.new("ShaderNodeVectorMath")
    nrm.operation = "NORMALIZE"
    L(tan.outputs["Vector"], nrm.inputs[0])
    dot = n.new("ShaderNodeVectorMath")
    dot.operation = "DOT_PRODUCT"
    L(nrm.outputs["Vector"], dot.inputs[0])
    L(geo.outputs["Position"], dot.inputs[1])

    def math(op, a, b=None):
        x = n.new("ShaderNodeMath")
        x.operation = op
        for i, v in enumerate((a, b)):
            if v is None:
                continue
            if isinstance(v, (int, float)):
                x.inputs[i].default_value = v
            else:
                L(v, x.inputs[i])
        return x.outputs[0]

    f = math("FRACT", math("DIVIDE", dot.outputs["Value"], spacing))
    d = math("MULTIPLY", math("MINIMUM", f, math("SUBTRACT", 1.0, f)), spacing)
    mr = n.new("ShaderNodeMapRange")
    mr.interpolation_type = "SMOOTHSTEP"
    mr.inputs["From Min"].default_value = 0.0
    mr.inputs["From Max"].default_value = seam_w
    mr.inputs["To Min"].default_value = 1.0
    mr.inputs["To Max"].default_value = 0.0
    L(d, mr.inputs["Value"])
    bp = n.new("ShaderNodeBump")
    bp.inputs["Strength"].default_value = bump
    bp.inputs["Distance"].default_value = 0.01
    L(mr.outputs["Result"], bp.inputs["Height"])
    L(bp.outputs["Normal"], bs.inputs["Normal"])
    # Macro variation: roughness + value drift over metres, so large roofs do not read as one flat sheet.
    nz = n.new("ShaderNodeTexNoise")
    nz.inputs["Scale"].default_value = 0.35
    nz.inputs["Detail"].default_value = 5
    L(geo.outputs["Position"], nz.inputs["Vector"])
    rr = n.new("ShaderNodeMapRange")
    rr.inputs["From Min"].default_value = 0.3
    rr.inputs["From Max"].default_value = 0.7
    rr.inputs["To Min"].default_value = rough[0]
    rr.inputs["To Max"].default_value = rough[1]
    L(nz.outputs["Fac"], rr.inputs["Value"])
    L(rr.outputs["Result"], bs.inputs["Roughness"])
    cr = n.new("ShaderNodeValToRGB")
    cr.color_ramp.elements[0].color = tuple(c * (1 - vary) for c in color) + (1,)
    cr.color_ramp.elements[1].color = tuple(min(1.0, c * (1 + vary)) for c in color) + (1,)
    L(nz.outputs["Fac"], cr.inputs["Fac"])
    L(cr.outputs["Color"], bs.inputs["Base Color"])
    bs.inputs["Metallic"].default_value = metal
    return m
