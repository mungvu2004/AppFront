# Scene extras added after the GLB import: gutters, fluted panels, interior props, surroundings, line weights.
import bpy, bmesh, math
from mathutils import Vector

G = -0.45


def _bbox(o):
    bb = [o.matrix_world @ Vector(c) for c in o.bound_box]
    return Vector([min(p[i] for p in bb) for i in range(3)]), Vector([max(p[i] for p in bb) for i in range(3)])


def gutters(house_col, roof_mat, metal):
    cu = bpy.data.curves.new("gutters", "CURVE")
    cu.dimensions = "3D"
    cu.bevel_depth = 0.065
    cu.bevel_resolution = 3
    cu.use_fill_caps = True
    n = 0
    for o in list(house_col.all_objects):
        if o.type != "MESH" or roof_mat.name not in [s.material.name for s in o.material_slots if s.material]:
            continue
        mn, mx = _bbox(o)
        bm = bmesh.new()
        bm.from_mesh(o.data)
        bm.transform(o.matrix_world)
        minz = min(v.co.z for v in bm.verts)
        for e in bm.edges:
            a, b = e.verts[0].co, e.verts[1].co
            if a.z > minz + 0.04 or b.z > minz + 0.04 or (a - b).length < 0.3:
                continue
            d = b - a
            if abs(d.y) < 0.05 and min(abs(a.y - mn.y), abs(a.y - mx.y)) < 0.25:
                out = Vector((0, -1 if abs(a.y - mn.y) < abs(a.y - mx.y) else 1, 0))
            elif abs(d.x) < 0.05 and min(abs(a.x - mn.x), abs(a.x - mx.x)) < 0.25:
                out = Vector((-1 if abs(a.x - mn.x) < abs(a.x - mx.x) else 1, 0, 0))
            else:
                continue
            sp = cu.splines.new("POLY")
            sp.points.add(1)
            for pt, v in zip(sp.points, (a, b)):
                q = v + out * 0.07 + Vector((0, 0, -0.06))
                pt.co = (q.x, q.y, q.z, 1)
            n += 1
        bm.free()
    ob = bpy.data.objects.new("gutter_all", cu)
    cu.materials.append(metal)
    house_col.objects.link(ob)
    return n


def fluted_panels(house_col, metal, fluted):
    for o in house_col.all_objects:
        if o.type != "MESH" or o.data.users != 1:
            continue
        names = [s.material.name if s.material else "" for s in o.material_slots]
        if metal.name not in names:
            continue
        mi = names.index(metal.name)
        o.data.materials.append(fluted)
        fi = len(o.data.materials) - 1
        for p in o.data.polygons:
            if p.material_index == mi and p.area > 0.8 and abs(p.normal.z) < 0.3:
                p.material_index = fi


def interior_props(house_col, place, box, M, lights_col):
    rug = box("prop_rug", (13.5, -11.2, 0.0), (15.1, -9.45, 0.012), M["rug"])
    place("potted_plant_02", 15.5, -9.7, 1.25, z=0.0)  # clear of the camera path through the door
    box("prop_lamp_base", (14.72, -10.62, 0.0), (14.98, -10.36, 0.03), M["metal"])
    box("prop_lamp_stem", (14.84, -10.5, 0.03), (14.86, -10.48, 1.45), M["metal"])
    bpy.ops.mesh.primitive_cylinder_add(radius=0.2, depth=0.32, location=(14.85, -10.49, 1.55))
    sh = bpy.context.object
    sh.name = "prop_lamp_shade"
    sh.data.materials.append(M["shade"])
    for c in sh.users_collection:
        c.objects.unlink(sh)
    house_col.objects.link(sh)
    ld = bpy.data.lights.new("lamp", "POINT")
    ld.energy = 60
    ld.color = (1.0, 0.6, 0.3)
    ld.shadow_soft_size = 0.08
    lo = bpy.data.objects.new("lamp", ld)
    lo.location = (14.85, -10.49, 1.5)
    lights_col.objects.link(lo)


def _shades(x, y, h, sun):
    s = 0.0
    while s < h * 3.7:
        px, py = x - sun.x * s, y - sun.y * s
        if -1 < px < 33 and -10 < py < 1:
            return True
        s += 1.0
    return False


def surroundings(house_col, place, rnd, box, M, sun_az):
    sun = Vector((math.cos(math.radians(sun_az)), math.sin(math.radians(sun_az)), 0))
    # Neighbouring garden walls (rendered, white) framing the plot and the far side of the lane.
    box("neigh_w", (-7.1, -60, G), (-6.9, 1.2, G + 1.9), M["plaster"])
    box("neigh_e", (46.9, -60, G), (47.1, 1.2, G + 1.9), M["plaster"])
    box("neigh_r", (-7.0, -44.1, G), (47.0, -43.9, G + 1.9), M["plaster"])
    box("neigh_f", (-90, 10.3, G), (130, 10.5, G + 1.7), M["plaster"])
    trees = ("island_tree_01", "tree_small_02", "island_tree_02")
    k = 0
    for gx in range(-80, 125, 6):
        for gy in range(-110, 70, 6):
            x, y = gx + rnd.uniform(-2.5, 2.5), gy + rnd.uniform(-2.5, 2.5)
            if -3 < x < 43 and -37 < y < 1.4:
                continue  # the plot
            if 1.0 < y < 10.9:
                continue  # the lane
            s = rnd.uniform(1.25, 2.1)
            if _shades(x, y, 5.0 * s, sun):
                # Sun side: low shrubs only, so the facade and lawn keep their light.
                if not _shades(x, y, 2.0, sun):
                    place("searsia_lucida", x, y, rnd.uniform(0.8, 1.2))
                    k += 1
                continue
            place(rnd.choice(trees), x, y, s)
            for _ in range(3):
                place("searsia_lucida", x + rnd.uniform(-3, 3), y + rnd.uniform(-3, 3), rnd.uniform(0.8, 1.5))
                k += 1
            k += 1
    # Understorey along the neighbour walls (layered planting the camera sees past the boundary).
    for i in range(80):
        side = rnd.choice(("w", "e", "f"))
        if side == "w":
            x, y = rnd.uniform(-6.5, -3.5), rnd.uniform(-43, 0.5)
        elif side == "e":
            x, y = rnd.uniform(43.5, 46.5), rnd.uniform(-43, 0.5)
        else:
            x, y = rnd.uniform(-60, 100), rnd.uniform(11.2, 14)
        if not _shades(x, y, 2.2, sun):
            place("searsia_lucida", x, y, rnd.uniform(0.7, 1.1))
            k += 1
    return k


def line_weights(sc, house_col):
    heavy = bpy.data.collections.new("LN_HEAVY")
    sc.collection.children.link(heavy)
    for o in house_col.all_objects:
        if o.type == "MESH" and (o.name.startswith("wall_") or o.name in ("site:render", "site:gate")):
            heavy.objects.link(o)


def run(sc, house_col, veg, M, place, rnd, sun_az, box):
    M["rug"] = M.get("rug") or _rug()
    M["shade"] = M.get("shade") or _shade()
    lights_col = bpy.data.collections["LIGHTS"]
    print("GUTTERS", gutters(house_col, M["roof"], M["metal"]))
    fluted_panels(house_col, M["metal"], M["fluted"])
    interior_props(house_col, place, box, M, lights_col)
    print("SURROUND", surroundings(house_col, place, rnd, box, M, sun_az))
    import interior
    interior.dress(sc, house_col, M, place)
    line_weights(sc, house_col)


def _rug():
    import lib
    return lib.simple("Rug", (0.42, 0.33, 0.24), rough=0.95)


def _shade():
    import lib
    return lib.simple("LampShade", (0.9, 0.82, 0.7), rough=0.8, emission=(1.0, 0.68, 0.4), strength=6)
