# Combo chapters 5-6: from A's final white-model camera (1:1) down to eye level, to the lit door, through it,
# across the hall and the dining room, ending on the living room. Keys: (t, pos, target, lens, shift_x, exposure).
import json, math
from mathutils import Euler, Vector

A = json.load(open("F:/App-review/homepage-v6/shared/combo/a-end-camera.json"))
A_POS = Vector(A["location_m"])
A_FWD = Euler(A["rotation_euler_xyz_rad"], "XYZ").to_matrix() @ Vector((0, 0, -1))
A_TGT = A_POS + A_FWD * A["focus_distance_m"]

KEYS = [
    (0.00, tuple(A_POS), tuple(A_TGT), A["lens_mm"], A["shift_x"], 0.0),
    (0.16, (-12.0, 22.0, 15.0), (13.0, -9.0, 2.0), 38.0, 0.0, 0.0),
    (0.32, (6.5, -1.3, 1.2), (14.5, -9.0, 2.5), 26.0, 0.0, 0.0),
    (0.42, (11.6, -5.2, 1.45), (13.3, -10.8, 1.55), 24.0, 0.0, 0.25),
    (0.50, (13.2, -8.7, 1.5), (13.3, -14.0, 1.5), 22.0, 0.0, 0.6),
    # Inside: turn right to the floating stair, then the hall, the dining room and the living-room vignette.
    (0.58, (13.0, -11.0, 1.55), (15.6, -12.9, 1.9), 22.0, 0.0, 0.8),
    (0.66, (11.7, -13.4, 1.5), (12.0, -18.0, 1.4), 22.0, 0.0, 0.8),
    (0.74, (12.6, -16.0, 1.5), (20.0, -18.0, 1.3), 23.0, 0.0, 0.8),
    (0.84, (17.0, -17.2, 1.45), (23.5, -18.8, 0.9), 24.0, 0.0, 0.8),
    (0.91, (21.0, -16.6, 1.4), (23.6, -19.2, 0.8), 26.0, 0.0, 0.8),
    (1.00, (23.9, -15.75, 1.35), (22.7, -19.4, 0.65), 26.0, 0.0, 0.8),
]


def _ease(p):
    s = p * p * (3 - 2 * p)
    return 0.6 * p + 0.4 * s


def _seg(ts, t):
    for k in range(len(ts) - 1):
        if t <= ts[k + 1]:
            return k
    return len(ts) - 2


def _cr(vals, ts, t):
    i = _seg(ts, t)
    u = (t - ts[i]) / (ts[i + 1] - ts[i])
    p0, p1, p2, p3 = vals[max(i - 1, 0)], vals[i], vals[i + 1], vals[min(i + 2, len(vals) - 1)]
    # Centripetal-ish: scale tangents by segment duration so uneven key spacing does not overshoot.
    d1 = ts[i + 1] - ts[i]
    m1 = (p2 - p0) * (d1 / (ts[min(i + 1, len(ts) - 1)] - ts[max(i - 1, 0)] or 1))
    m2 = (p3 - p1) * (d1 / (ts[min(i + 2, len(ts) - 1)] - ts[i] or 1))
    u2, u3 = u * u, u * u * u
    return (2 * u3 - 3 * u2 + 1) * p1 + (u3 - 2 * u2 + u) * m1 + (-2 * u3 + 3 * u2) * p2 + (u3 - u2) * m2


def at(p):
    t = _ease(min(max(p, 0.0), 1.0))
    ts = [k[0] for k in KEYS]
    pos = _cr([Vector(k[1]) for k in KEYS], ts, t)
    tgt = _cr([Vector(k[2]) for k in KEYS], ts, t)
    lens, shift, expo = (_cr([Vector((k[3], k[4], k[5])) for k in KEYS], ts, t))
    return pos, tgt, lens, shift, expo


def set_cam(cam, p, scene=None):
    pos, tgt, lens, shift, expo = at(p)
    cam.location = pos
    cam.rotation_euler = (tgt - pos).to_track_quat("-Z", "Y").to_euler()
    cam.data.lens = lens
    cam.data.shift_x = shift
    cam.data.sensor_width = A["sensor_width_mm"]
    cam.data.sensor_fit = "AUTO"
    cam.data.dof.use_dof = True
    cam.data.dof.focus_distance = (tgt - pos).length
    # Far away: f/8-ish sharp real-photo look; close: f/4 like the cinema stills.
    cam.data.dof.aperture_fstop = 8.0 if (tgt - pos).length > 30 else 4.0
    if scene is not None:
        scene.view_settings.exposure = expo


if __name__ == "__main__":
    print("A_TGT", tuple(round(c, 3) for c in A_TGT), "rot0", tuple(round(math.degrees(a), 3) for a in (A_TGT - A_POS).to_track_quat("-Z", "Y").to_euler()))
    for i in range(0, 11):
        pos, tgt, lens, sh, ex = at(i / 10)
        print(i / 10, tuple(round(c, 2) for c in pos), round(lens, 1), round(sh, 3), round(ex, 2))
