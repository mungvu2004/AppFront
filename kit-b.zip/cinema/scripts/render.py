# Render one frame of the move. args: --p 0.5 --pass beauty|lines --out path [--samples N] [--res 1920x1080]
import bpy, sys, math, time, argparse
from mathutils import Vector
sys.path.insert(0, "F:/App-review/homepage-v6/cinema/scripts")
import lib, importlib

ap = argparse.ArgumentParser()
ap.add_argument("--p", type=float, default=1.0)
ap.add_argument("--pass", dest="pas", default="beauty")
ap.add_argument("--out", default="")
ap.add_argument("--frames", default="")  # "a:b" -> frames a..b-1 of --n, written to --outdir
ap.add_argument("--n", type=int, default=120)
ap.add_argument("--outdir", default="")
ap.add_argument("--list", default="")
ap.add_argument("--path", default="cam")
ap.add_argument("--webp", default="F:/worktrees/AppFront/homepage-v6/public/landing-lab/cinema/1920/{k}_{i:03d}.webp")
ap.add_argument("--samples", type=int, default=256)
ap.add_argument("--clay", action="store_true")  # house in A's warm-white card look, landscape unchanged
ap.add_argument("--res", default="1920x1080")
a = ap.parse_args(sys.argv[sys.argv.index("--") + 1:])
camlib = importlib.import_module(a.path)
sc = bpy.context.scene
w, h = map(int, a.res.split("x"))
camlib.set_cam(sc.camera, a.p, sc)
if a.clay:
    clay = lib.simple("Clay", (0.80, 0.78, 0.74), rough=0.85)
    clay.node_tree.nodes["Principled BSDF"].inputs["Subsurface Weight"].default_value = 0.08
    for ob in sc.objects:
        if ob.type not in ("MESH", "CURVE"):
            continue
        if ob.get("grp") in ("level_0", "level_1", "level_2", "roofs") or ob.name.startswith(("plinth_", "sill_", "gutter_", "ceiling_")):
            for sl in ob.material_slots:
                if sl.material and sl.material.name != "Glass":
                    sl.link = "OBJECT"
                    sl.material = clay
if a.pas == "beauty":
    lib.setup_render(sc, samples=a.samples, res=(w, h))
    sc.render.image_settings.file_format = "JPEG"
    sc.render.image_settings.quality = 92
    # Atmospheric depth: warm haze from the mist pass, composited.
    sc.view_layers[0].use_pass_mist = True
    sc.world.mist_settings.start = 25
    sc.world.mist_settings.depth = 320
    sc.world.mist_settings.falloff = "QUADRATIC"
    sc.use_nodes = True
    nt = sc.node_tree
    nt.nodes.clear()
    rl = nt.nodes.new("CompositorNodeRLayers")
    mx = nt.nodes.new("CompositorNodeMixRGB")
    mx.inputs[2].default_value = (0.95, 0.80, 0.62, 1)
    mul = nt.nodes.new("CompositorNodeMath")
    mul.operation = "MULTIPLY"
    mul.inputs[1].default_value = 0.42
    # Sky has mist 1.0: mask it out so the sky keeps its colour; geometry hazes with distance.
    lt = nt.nodes.new("CompositorNodeMath")
    lt.operation = "LESS_THAN"
    lt.inputs[1].default_value = 0.999
    nt.links.new(rl.outputs["Mist"], lt.inputs[0])
    mm = nt.nodes.new("CompositorNodeMath")
    mm.operation = "MULTIPLY"
    nt.links.new(rl.outputs["Mist"], mm.inputs[0])
    nt.links.new(lt.outputs[0], mm.inputs[1])
    nt.links.new(mm.outputs[0], mul.inputs[0])
    nt.links.new(mul.outputs[0], mx.inputs[0])
    nt.links.new(rl.outputs["Image"], mx.inputs[1])
    co = nt.nodes.new("CompositorNodeComposite")
    nt.links.new(mx.outputs[0], co.inputs[0])
else:
    import lines
    lines.setup(sc, (w, h))
import os
if a.list:
    for item in a.list.split(";"):
        pv, out = item.split("=", 1)
        camlib.set_cam(sc.camera, float(pv), sc)
        sc.render.filepath = out
        t0 = time.time()
        bpy.ops.render.render(write_still=True)
        print("RENDER_S", round(time.time() - t0, 1), a.pas, pv, flush=True)
elif a.frames:
    lo, hi = map(int, a.frames.split(":"))
    ext = "jpg" if a.pas == "beauty" else "png"
    for i in range(lo, min(hi, a.n)):
        out = f"{a.outdir}/{a.pas[0]}_{i:03d}.{ext}"
        webp = a.webp.format(k=a.pas[0], i=i)
        if os.path.exists(out) or os.path.exists(webp):
            continue
        camlib.set_cam(sc.camera, i / (a.n - 1), sc)
        sc.render.filepath = out
        t0 = time.time()
        bpy.ops.render.render(write_still=True)
        print("FRAME", i, round(time.time() - t0, 1), flush=True)
else:
    sc.render.filepath = a.out
    t0 = time.time()
    bpy.ops.render.render(write_still=True)
    print("RENDER_S", round(time.time() - t0, 1), a.pas, a.p)
