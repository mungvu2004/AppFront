# Combo interior walk, v2 (owner): keeps cam_int frames 0..11 (approach), then from frame 11's exact pose:
# threshold -> hall -> dining -> living room, slow push to the hero vignette, ~20-frame drift on the
# still-interior-v2 composition. No stair turn. Rendered frames are int_0012 .. int_0087.
import cam_int  # noqa: F401  (sets cam_combo.KEYS to the v1 interior path)
import cam_combo as cc
from mathutils import Vector

N = 76  # frame i of this part == int_{11 + i}; i = 0 is int_0011 (already rendered), render i = 1..75
_P10 = cc.at(10 / 63)
_P11 = cc.at(11 / 63)
_DT = 1.0 / (N - 1)


def _k(t, pose):
    pos, tgt, lens, shift, expo = pose
    return (t, tuple(pos), tuple(tgt), lens, shift, expo)


KEYS2 = [
    _k(-_DT, _P10),  # phantom: carries the velocity of the frames already on the page
    _k(0.0, _P11),
    (0.13, (13.2, -8.7, 1.5), (13.2, -14.0, 1.5), 22.0, 0.0, 0.0),
    (0.22, (12.6, -12.2, 1.5), (12.0, -17.5, 1.4), 22.0, 0.0, 0.0),
    (0.34, (12.3, -15.6, 1.5), (19.0, -18.0, 1.3), 23.0, 0.0, 0.0),
    (0.48, (16.6, -17.4, 1.45), (23.5, -18.8, 0.9), 24.0, 0.0, 0.0),
    (0.62, (21.8, -16.6, 1.5), (22.6, -19.4, 0.8), 25.0, 0.0, 0.0),
    (0.76, (25.6, -16.25, 1.55), (21.4, -19.5, 0.72), 26.0, 0.0, 0.0),
    (1.00, (27.2, -16.2, 1.55), (21.0, -19.6, 0.7), 25.0, 0.0, 0.0),
]


def _ease(p):
    # constant speed out of the kept frames, gentle ease-out into the linger
    return 0.45 * p + 0.55 * p * (2 - p)


def at(p):
    t = _ease(min(max(p, 0.0), 1.0))
    ts = [k[0] for k in KEYS2]
    pos = cc._cr([Vector(k[1]) for k in KEYS2], ts, t)
    tgt = cc._cr([Vector(k[2]) for k in KEYS2], ts, t)
    lens, shift, expo = cc._cr([Vector((k[3], k[4], k[5])) for k in KEYS2], ts, t)
    return pos, tgt, lens, shift, expo


def set_cam(cam, p, scene=None):
    import bpy
    pos, tgt, lens, shift, expo = at(p)
    cam.location = pos
    cam.rotation_euler = (tgt - pos).to_track_quat("-Z", "Y").to_euler()
    cam.data.lens = lens
    cam.data.shift_x = shift
    cam.data.sensor_width = 36.0
    cam.data.dof.use_dof = True
    cam.data.dof.focus_distance = (tgt - pos).length
    cam.data.dof.aperture_fstop = 4.0
    if scene is not None:
        scene.view_settings.exposure = expo
    sun = bpy.data.objects.get("fake_sun")
    if sun:
        sun.hide_render = False


if __name__ == "__main__":
    prev = None
    for i in range(0, N, 5):
        pos = at(i / (N - 1))[0]
        print("K", 12 + i, [round(c, 2) for c in pos], round((pos - prev).length / 5, 2) if prev else "")
        prev = pos
    print("old step 10->11", round((_P11[0] - _P10[0]).length, 2), "new 0->1", round((at(1 / (N - 1))[0] - _P11[0]).length, 2))
