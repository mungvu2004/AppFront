# Import Poly Haven glTF models into one library blend, one collection per model.
import bpy, glob, os
ROOT = "F:/App-review/homepage-v6/cinema/assets/models"
bpy.ops.wm.read_factory_settings(use_empty=True)
for path in sorted(glob.glob(f"{ROOT}/*/*.gltf")):
    name = os.path.basename(os.path.dirname(path))
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=path)
    new = [o for o in bpy.data.objects if o not in before]
    col = bpy.data.collections.new("veg_" + name)
    bpy.context.scene.collection.children.link(col)
    tris = 0
    for o in new:
        for c in o.users_collection: c.objects.unlink(o)
        col.objects.link(o)
        if o.type == "MESH":
            tris += sum(len(p.vertices) - 2 for p in o.data.polygons)
    import mathutils
    pts = [o.matrix_world @ mathutils.Vector(c) for o in new if o.type == "MESH" for c in o.bound_box]
    mn = [min(p[i] for p in pts) for i in range(3)]; mx = [max(p[i] for p in pts) for i in range(3)]
    print(f"VEG {name}: objs={len(new)} tris={tris} min={[round(v,2) for v in mn]} max={[round(v,2) for v in mx]} mats={[m.name for o in new if o.type=='MESH' for m in o.data.materials]}")
bpy.ops.file.pack_all() if False else None
bpy.ops.wm.save_as_mainfile(filepath="F:/App-review/homepage-v6/cinema/blend/veg_lib.blend")
