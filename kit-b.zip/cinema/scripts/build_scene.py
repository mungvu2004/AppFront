# Build the cinema master scene from the shared house GLB: re-material, real vegetation, grass, lights.
# Run: blender -b -P build_scene.py   -> blend/cinema.blend
import bpy, sys, math, random, re
from mathutils import Vector

sys.path.insert(0, "F:/App-review/homepage-v6/cinema/scripts")
import lib

GLB = "F:/App-review/homepage-v6/shared/house.glb"
VEG = "F:/App-review/homepage-v6/cinema/blend/veg_lib.blend"
OUT = "F:/App-review/homepage-v6/cinema/blend/cinema.blend"
G = -0.45  # natural ground (FFL = 0)

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
lib.setup_render(sc)
SUN_AZ = 32
lib.setup_world(sc, hdri="kloppenheim_06_puresky", strength=1.0, sun_az_deg=SUN_AZ, sun_strength=7.0, sun_elev=15, sun_color=(1.0, 0.66, 0.38))

bpy.ops.import_scene.gltf(filepath=GLB)
house_col = bpy.data.collections.new("HOUSE")
sc.collection.children.link(house_col)
for o in list(sc.collection.objects):
    if o.name not in ("Sun",):
        sc.collection.objects.unlink(o)
        house_col.objects.link(o)

# Drop the GLB's low-poly plants entirely.
plants_root = bpy.data.objects.get("site_plants")
if plants_root:
    for o in [plants_root, *plants_root.children_recursive]:
        bpy.data.objects.remove(o, do_unlink=True)

# ---------- materials ----------
M = {
    "plaster": lib.pbr("Plaster", "white_plaster_02", size_m=3.0, sat=0.2, val=1.2, bump=0.2, flat=(0.80, 0.77, 0.71), flat_mix=0.72),
    "paint": lib.simple("WhitePaint", (0.72, 0.70, 0.66), rough=0.42),
    "meadow": lib.pbr("ForestFloor", "forest_ground_04", size_m=4.0, tint=(0.55, 0.75, 0.4), sat=0.9, val=0.55, vary=0.35),
    "asphalt": lib.pbr("GravelLane", "gravel_floor_02", size_m=2.5, tint=(0.8, 0.7, 0.58), sat=0.5, val=0.5, vary=0.2),
    "fluted": lib.ribbed("FlutedBronze", (0.07, 0.05, 0.035), metal=0.85, rough=(0.28, 0.42), spacing=0.07, seam_w=0.035, bump=0.5),
    "stone": lib.pbr("StoneBase", "stacked_stone_wall", size_m=1.6, sat=0.25, val=1.35, bump=0.6),
    "cedar": lib.pbr("Cedar", "japanese_cedar_planks", size_m=2.4, sat=0.75, val=0.75, bump=0.4),
    "roof": lib.ribbed("StandingSeam", (0.042, 0.044, 0.047), metal=0.7, rough=(0.26, 0.5), spacing=0.48, seam_w=0.022, bump=0.7, vary=0.18),
    "deck": lib.pbr("Deck", "wood_floor_deck", size_m=2.0, sat=0.8, val=0.8),
    "slab": lib.pbr("Limestone", "concrete_floor_02", size_m=2.0, tint=(0.95, 0.92, 0.85), sat=0.3, val=1.25, bump=0.3),
    "pavers": lib.pbr("Pavers", "grooved_concrete_driveway", size_m=3.0, sat=0.4, val=1.0),
    "granite": lib.pbr("Granite", "concrete_floor_02", size_m=1.5, tint=(0.6, 0.58, 0.55), sat=0.2, val=0.8),
    "soil": lib.pbr("Mulch", "farm_soil", size_m=1.5, sat=0.8, val=0.55),
    "lawnbase": lib.pbr("LawnBase", "leafy_grass", size_m=2.5, tint=(0.45, 0.55, 0.24), sat=0.8, val=0.85),
    "glass": lib.glass(),
    "metal": lib.simple("DarkMetal", (0.025, 0.024, 0.022), rough=0.38, metal=0.85),
    "ridge": lib.simple("Ridge", (0.07, 0.072, 0.075), rough=0.55, metal=0.3),
    "fascia": lib.simple("Fascia", (0.06, 0.06, 0.058), rough=0.5, metal=0.4),
    "boulder": lib.pbr("Boulder", "stacked_stone_wall", size_m=1.2, sat=0.15, val=1.1, bump=0.8),
    "water": lib.simple("Water", (0.025, 0.06, 0.05), rough=0.02, transmission=0.0),
    "door": lib.pbr("DoorWood", "japanese_cedar_planks", size_m=1.2, sat=0.7, val=0.45),
    "woodfloor": lib.pbr("WoodFloor", "wood_floor", size_m=2.4, sat=0.85, val=0.85, rough_mul=0.8),
    "tilefloor": lib.simple("TileFloor", (0.62, 0.6, 0.56), rough=0.25),
    "soffitlight": lib.simple("SoffitLight", (1, 1, 1), emission=(1.0, 0.62, 0.32), strength=40),
    "pathlight": lib.simple("PathLight", (0.05, 0.05, 0.05), emission=(1.0, 0.6, 0.3), strength=15),
}


def pick(mat, obj):
    n = re.sub(r"\.\d+$", "", mat.name)
    on = obj.name
    if n in ("plaster", "cut", "render_mat"):
        return M["plaster"]
    if n == "exterior":
        return M["plaster"]
    bs = mat.node_tree.nodes.get("Principled BSDF") if mat.use_nodes else None
    if n == "glass" or (bs and bs.inputs["Alpha"].default_value < 0.9 and n == "roof_parts_part_mat"):
        return M["glass"]
    if n in ("metal", "gate_mat", "roof_parts_part_mat", "path-lights_mat"):
        return M["metal"]
    if n == "folded_mat":
        return M["metal"]
    if n in ("RF1_mat", "RF2_mat", "RF3_mat"):
        sub = mat.name.split(".")[-1] if "." in mat.name else ""
        return {"": M["roof"], "001": M["fascia"], "002": M["cedar"], "003": M["ridge"]}.get(sub, M["roof"])
    if n == "decking":
        return M["deck"]
    if n == "woodFloor":
        return M["woodfloor"]
    if n in ("tileFloor", "mosaicFloor"):
        return M["tilefloor"]
    if n == "stone_mat":
        return M["slab"]
    if n == "paving_mat":
        return M["pavers"]
    if n == "granite_mat":
        return M["granite"]
    if n == "bed_mat":
        return M["soil"]
    if n == "lawn_mat":
        return M["lawnbase"]
    if n == "stone-seats_mat":
        return M["boulder"]
    if n == "POND:water_mat":
        return M["water"]
    if n == "soffitLights_mat":
        return M["soffitlight"]
    if n == "paint" and on.startswith("door_D1"):
        return M["door"]
    if n == "paint":
        return M["paint"]
    if n.startswith("wall_") and n.endswith("_part_mat"):
        zs = [(obj.matrix_world @ Vector(c)).z for c in obj.bound_box]
        if max(zs) - min(zs) < 0.3:
            return M["plaster"]  # slab band between tiers stays white
        return M["stone"] if sum(zs) / 8 < 3.0 else M["cedar"]
    return None


for o in house_col.all_objects:
    if o.type != "MESH":
        continue
    for slot in o.material_slots:
        if slot.material:
            new = pick(slot.material, o)
            if new:
                slot.link = "OBJECT" if o.data.users > 1 else "DATA"
                slot.material = new
# Remember each object's top group (level_N / roofs / site) before parents are cleared.
for o in house_col.all_objects:
    a = o
    while a.parent and not (a.name.startswith("level_") and a.name[6:].isdigit() or a.name in ("roofs", "site")):
        a = a.parent
    o["grp"] = a.name if a.parent is not None or a.name in ("roofs", "site") or a.name.startswith("level_") else ""

# Apply transforms so object coords = world metres (box-projected textures line up across parts).
bpy.ops.object.select_all(action="DESELECT")
for o in house_col.all_objects:
    if o.type == "MESH" and o.data.users == 1:
        o.select_set(True)
bpy.context.view_layer.objects.active = next((o for o in house_col.all_objects if o.select_get()), None)
bpy.ops.object.parent_clear(type="CLEAR_KEEP_TRANSFORM")
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

# ---------- facade detail: stone plinth and window sills ----------
def box(name, mn, mx, mat):
    bpy.ops.mesh.primitive_cube_add(size=1, location=[(a + b) / 2 for a, b in zip(mn, mx)])
    o = bpy.context.object
    o.name = name
    o.scale = [b - a for a, b in zip(mn, mx)]
    bpy.ops.object.transform_apply(scale=True)
    o.data.materials.append(mat)
    for c in o.users_collection:
        c.objects.unlink(o)
    house_col.objects.link(o)
    return o


for x0, x1 in ((3.83, 10.6), (15.4, 28.17)):
    box("plinth_front", (x0, -8.86, -0.45), (x1, -8.80, 0.42), M["stone"])
box("plinth_w", (3.80, -21.17, -0.45), (3.86, -8.83, 0.42), M["stone"])
box("plinth_e", (28.14, -21.17, -0.45), (28.20, -8.83, 0.42), M["stone"])
for o in list(house_col.all_objects):
    if o.type == "MESH" and o.name.startswith("window_"):
        bb = [o.matrix_world @ Vector(c) for c in o.bound_box]
        mn = Vector([min(p[i] for p in bb) for i in range(3)])
        mx = Vector([max(p[i] for p in bb) for i in range(3)])
        if mn.z < 0.1:
            continue  # sliding doors to the floor get no sill
        if mx.y - mn.y < 0.1:  # in an east-west wall
            side = 1 if mn.y > -15 else -1
            yc = (mn.y + mx.y) / 2 + side * 0.12
            box("sill_" + o.name, (mn.x - 0.06, yc - 0.1, mn.z - 0.05), (mx.x + 0.06, yc + 0.1, mn.z - 0.01), M["metal"])
        elif mx.x - mn.x < 0.1:
            side = 1 if mn.x > 16 else -1
            xc = (mn.x + mx.x) / 2 + side * 0.12
            box("sill_" + o.name, (xc - 0.1, mn.y - 0.06, mn.z - 0.05), (xc + 0.1, mx.y + 0.06, mn.z - 0.01), M["metal"])

# ---------- interior glow ----------
lights_col = bpy.data.collections.new("LIGHTS")
sc.collection.children.link(lights_col)
for o in list(house_col.all_objects):
    if o.type == "MESH" and o.name.startswith("slab_") and not o.name.startswith("slab_TR"):
        bb = [o.matrix_world @ Vector(c) for c in o.bound_box]
        mn = Vector([min(p[i] for p in bb) for i in range(3)])
        mx = Vector([max(p[i] for p in bb) for i in range(3)])
        sx, sy = mx.x - mn.x, mx.y - mn.y
        if sx < 0.8 or sy < 0.8:
            continue
        ld = bpy.data.lights.new("room_" + o.name, "AREA")
        ld.shape = "RECTANGLE"
        ld.size, ld.size_y = sx * 0.55, sy * 0.55
        ld.energy = 38 * sx * sy * (0.3 if o.name[:7] in ("slab_G1", "slab_G2", "slab_G3") else 1.0)  # spots light the walk-in rooms
        ld.color = (1.0, 0.66, 0.38)
        ld.spread = math.radians(150)
        lo = bpy.data.objects.new("room_" + o.name, ld)
        lo.visible_camera = False  # seen through glass they read as lamps
        lo.visible_glossy = False
        lo.visible_transmission = False
        lo.location = ((mn.x + mx.x) / 2, (mn.y + mx.y) / 2, mx.z + 2.75)
        lights_col.objects.link(lo)
for o in list(house_col.all_objects):
    if o.type == "MESH" and o.name.startswith("site:path-lights#"):
        bb = [o.matrix_world @ Vector(c) for c in o.bound_box]
        top = max(p.z for p in bb)
        cx = sum(p.x for p in bb) / 8
        cy = sum(p.y for p in bb) / 8
        ld = bpy.data.lights.new("bollard", "POINT")
        ld.energy = 4
        ld.color = (1.0, 0.62, 0.32)
        ld.shadow_soft_size = 0.03
        lo = bpy.data.objects.new("bollard", ld)
        lo.location = (cx, cy, top + 0.025)
        lights_col.objects.link(lo)

# ---------- vegetation ----------
with bpy.data.libraries.load(VEG, link=False) as (src, dst):
    dst.collections = [c for c in src.collections]
veg_src = bpy.data.collections.new("VEG_SRC")
sc.collection.children.link(veg_src)
proto = {}
for c in dst.collections:
    veg_src.children.link(c)
    if c.name.startswith(("veg_potted_plant", "veg_modern_wooden_cabinet", "veg_sofa_02")):
        # Pot + leaves + soil are separate objects: keep the whole model as one prototype.
        pts = [o.matrix_world @ Vector(v) for o in c.objects if o.type == "MESH" for v in o.bound_box]
        c.instance_offset = (sum(p.x for p in pts) / len(pts), sum(p.y for p in pts) / len(pts), min(p.z for p in pts))
        proto[c.name[4:]] = [c]
        continue
    # Each model's variants sit side by side: split into separate prototype collections per object.
    for i, o in enumerate(sorted(c.objects, key=lambda o: o.name)):
        if o.type != "MESH":
            continue
        pc = bpy.data.collections.new(f"{c.name}_{i}")
        veg_src.children.link(pc)
        pc.objects.link(o)
        c.objects.unlink(o)
        bb = [Vector(v) for v in o.bound_box]
        cx = sum((o.matrix_world @ v).x for v in bb) / 8
        cy = sum((o.matrix_world @ v).y for v in bb) / 8
        mnz = min((o.matrix_world @ v).z for v in bb)
        pc.instance_offset = (cx, cy, mnz)
        proto.setdefault(c.name[4:], []).append(pc)
veg_src.hide_render = True
veg_src.hide_viewport = True
for c in veg_src.children:
    c.hide_render = False  # instances still render; parent exclusion is via layer below
lc = bpy.context.view_layer.layer_collection.children["VEG_SRC"]
lc.exclude = True

# Leaves: add translucency to imported leaf materials.
for m in bpy.data.materials:
    if any(k in m.name for k in ("leaves", "searsia_lucida", "shrub", "fern", "grass_bermuda")) and m.use_nodes:
        nt = m.node_tree
        bs = nt.nodes.get("Principled BSDF")
        out = nt.nodes.get("Material Output")
        if not bs or not out or nt.nodes.get("LeafMix"):
            continue
        tl = nt.nodes.new("ShaderNodeBsdfTranslucent")
        if bs.inputs["Base Color"].links:
            nt.links.new(bs.inputs["Base Color"].links[0].from_socket, tl.inputs["Color"])
        mx = nt.nodes.new("ShaderNodeMixShader")
        mx.name = "LeafMix"
        mx.inputs["Fac"].default_value = 0.25
        nt.links.new(bs.outputs["BSDF"], mx.inputs[1])
        nt.links.new(tl.outputs["BSDF"], mx.inputs[2])
        nt.links.new(mx.outputs["Shader"], out.inputs["Surface"])

veg = bpy.data.collections.new("VEG")
sc.collection.children.link(veg)
rnd = random.Random(7)


def place(kind, x, y, s, z=G, rot=None, variant=None):
    lst = proto[kind]
    pc = lst[variant % len(lst)] if variant is not None else rnd.choice(lst)
    e = bpy.data.objects.new(f"v_{kind}", None)
    e.instance_type = "COLLECTION"
    e.instance_collection = pc
    e.location = (x, y, z)
    e.scale = (s, s, s)
    e.rotation_euler = (0, 0, rot if rot is not None else rnd.uniform(0, math.tau))
    veg.objects.link(e)
    return e


# Specimen trees (plan positions from site.ts, Blender y = -plan y).
place("island_tree_02", 6.0, -4.0, 1.05)
place("island_tree_02", 24.0, -4.0, 1.0)
place("searsia_lucida", 9.4, -7.4, 0.55)
place("searsia_lucida", 20.25, -29.0, 0.6, z=-0.15)
place("searsia_lucida", 6.2, -26.9, 0.55)
place("island_tree_01", 32.5, -28.5, 1.45)
place("tree_small_02", 5.5, -31.0, 1.4)
for x, y in ((36.0, -19.5), (37.3, -24.6), (35.8, -29.6)):
    place("island_tree_02", x, y, rnd.uniform(0.85, 1.05))
for x, y, s in ((37.0, -4.8, 1.3), (35.7, -6.5, 1.1), (10.3, -30.9, 1.3), (11.5, -31.9, 1.1), (9.4, -32.0, 1.0)):
    place("tree_small_02", x, y, s)

def hedge_line(a, b, step, s=(0.6, 0.85)):
    a, b = Vector(a), Vector(b)
    n = max(1, int((b - a).length / step))
    for i in range(n + 1):
        p = a.lerp(b, i / n) + Vector((rnd.uniform(-0.25, 0.25), rnd.uniform(-0.25, 0.25)))
        place("searsia_lucida", p.x, p.y, rnd.uniform(*s))


hedge_line((0.8, -1.6), (0.8, -33.2), 1.7)
hedge_line((39.2, -1.6), (39.2, -33.2), 1.7)
hedge_line((2.0, -33.2), (38.0, -33.2), 1.7)
hedge_line((4.6, -8.6), (10.2, -8.6), 0.55, s=(0.36, 0.5))
hedge_line((15.9, -8.6), (27.6, -8.6), 0.55, s=(0.36, 0.5))
for x, y in ((11.1, -1.5), (10.4, -1.8), (10.9, -2.5), (14.9, -1.5), (15.6, -1.8), (15.1, -2.5), (11.0, -5.0), (10.3, -5.4), (11.1, -5.9)):
    place("searsia_lucida", x, y, rnd.uniform(0.22, 0.3))
# Ground cover in the beds along the house front.
for i in range(190):
    x = rnd.uniform(4.2, 27.8)
    if 10.3 < x < 15.7:
        continue
    place(rnd.choice(["fern_02", "shrub_04", "shrub_03", "shrub_01"]), x, rnd.uniform(-8.25, -8.95), rnd.uniform(0.7, 1.1))

# ---------- surroundings: meadow ground and the street ----------
bpy.ops.mesh.primitive_plane_add(size=600, location=(20, -17, G - 0.02))
gp = bpy.context.object
gp.name = "ground_far"
gp.data.materials.append(M["meadow"])
bpy.ops.mesh.primitive_plane_add(size=1, location=(20, 5.5, G - 0.005))
rd = bpy.context.object
rd.name = "street"
rd.scale = (400, 8.8, 1)
rd.data.materials.append(M["asphalt"])
for o in (gp, rd):
    bpy.ops.object.select_all(action="DESELECT")
    o.select_set(True)
    bpy.context.view_layer.objects.active = o
    bpy.ops.object.transform_apply(scale=True)  # box-projected textures must not stretch
    for c in o.users_collection:
        c.objects.unlink(o)
    house_col.objects.link(o)

import extras
extras.run(sc, house_col, veg, M, place, rnd, SUN_AZ, box)

# ---------- lawn grass ----------
lawn = bpy.data.objects.get("site:lawn")
patch = lib.grass_patch()
grass_col = bpy.data.collections.new("GRASS_SRC")
sc.collection.children.link(grass_col)
grass_col.objects.link(patch)
bpy.context.view_layer.layer_collection.children["GRASS_SRC"].exclude = True
lib.grass_scatter(lawn, patch, density=9, holes=[(11.95, -7.3, 14.05, -0.55), (16.1, -31.95, 17.9, -25.25), (29.3, -9.1, 34.7, -0.5), (27.9, -16.2, 34.7, -8.9)])

# ---------- camera ----------
cam = bpy.data.objects.new("Cam", bpy.data.cameras.new("Cam"))
sc.collection.objects.link(cam)
sc.camera = cam
cam.data.sensor_width = 36
cam.data.clip_start = 0.1
cam.data.clip_end = 600

bpy.ops.wm.save_as_mainfile(filepath=OUT)
print("BUILD_OK", len(veg.objects), "veg instances")
