Kit B: cinema interior walk at double density (prototype B, combo page).

Contents: cinema/scripts (scene build + camera + render scripts, unchanged except the F:/ paths that
kit.py setup rewrites to KIT_ROOT), shared/house.glb, shared/combo/a-end-camera.json, assets-manifest.json
(218 Poly Haven CC0 files, 486 MB, downloaded by kit.py setup from dl.polyhaven.org).

Steps (render_b.ipynb does all of this):
  python kit.py setup
  blender -b -P cinema/scripts/make_veg_lib.py      -> cinema/blend/veg_lib.blend
  blender -b -P cinema/scripts/build_scene.py       -> cinema/blend/cinema.blend
  blender -b cinema/blend/cinema.blend -P cinema/scripts/render.py -- --path cam_int2 --pass beauty --samples 160 --list "<p>=<out.jpg>;..."

Frame mapping (int = shipped 87 frames, int2 = new 173 frames, int2_0000..int2_0172):
  int2_(2k)   = int_k (already rendered: copy/rename, not rendered by this kit)
  int2_(2k+1) = new, halfway in path time between int_k and int_(k+1)
     k = 0..10  : cam_int  at p = (2k+1)/126   (int_k was cam_int at p = k/63, 160 spp)
     k = 11..85 : cam_int2 at p = (2k-21)/150  (int_k was cam_int2 at p = (k-11)/75, 160 spp)
  "python kit.py frames" prints the frames to render (98 by default, 86 with APPROACH_EVENS=0).

Approach evens (int2_0000..int2_0022, default ON): the shipped int_0000..0011 were rendered ~10:35-10:56 from an
older cinema.blend (doormat recess on the entry step, step base down to the ground). int_0012+ and this kit's
build are the current scene (no doormat, dark gap under the step). New odd frames next to old evens would flicker,
so the kit also re-renders the 12 even approach frames; use them in place of int_0000..int_0011.
From int2_0024 on, even frames = shipped int_k (k = t/2), same scene, pose bit-identical.
WebP like the shipped set: 1920 and 1280 (LANCZOS), quality 76, method 6.
