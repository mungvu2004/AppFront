"""Cinema interior kit (prototype B). usage:
  python kit.py setup          rewrite the scripts' F:/ paths to KIT_ROOT, fetch Poly Haven assets (CC0) from the manifest
  python kit.py frames         print the new odd frames: name path p
KIT_ROOT defaults to the folder of this file."""
import json, os, sys, urllib.request
from concurrent.futures import ThreadPoolExecutor

ROOT = (os.environ.get("KIT_ROOT") or os.path.dirname(os.path.abspath(__file__))).replace("\\", "/")
OLD = "F:/App-review/homepage-v6"


def fetch(item):
    path = f"{ROOT}/cinema/assets/{item['path']}"
    if os.path.exists(path) and os.path.getsize(path) == item["size"]:
        return 0
    os.makedirs(os.path.dirname(path), exist_ok=True)
    req = urllib.request.Request(item["url"], headers={"User-Agent": "cinema-kit"})
    for _ in range(3):
        try:
            with urllib.request.urlopen(req, timeout=120) as r, open(path + ".part", "wb") as f:
                while chunk := r.read(1 << 20):
                    f.write(chunk)
            if os.path.getsize(path + ".part") == item["size"]:
                os.replace(path + ".part", path)
                return item["size"]
        except OSError as e:
            print("retry", item["path"], e, flush=True)
    raise SystemExit(f"download failed: {item['url']}")


def setup():
    d = f"{ROOT}/cinema/scripts"
    for f in os.listdir(d):
        if f.endswith(".py"):
            s = open(f"{d}/{f}", encoding="utf-8").read()
            if OLD in s:
                open(f"{d}/{f}", "w", encoding="utf-8").write(s.replace(OLD, ROOT))
    os.makedirs(f"{ROOT}/cinema/blend", exist_ok=True)
    items = json.load(open(f"{ROOT}/assets-manifest.json"))
    with ThreadPoolExecutor(8) as ex:
        got = sum(ex.map(fetch, items))
    print(f"assets ok: {len(items)} files, downloaded {got / 1e6:.0f} MB", flush=True)


def frames(approach_evens=os.environ.get("APPROACH_EVENS", "1") == "1"):
    """int2_(2k) == int_k (already rendered). New odd frames, same camera functions as the originals:
    int_0000..0011 came from cam_int at p = k/63, int_0012..0086 from cam_int2 at p = (k-11)/75.
    approach_evens: also re-render int2_0000..0022 (even) because the shipped int_0000..0011 came from an
    older scene state (doormat, step to ground) than int_0012+ and than this build; mixing them would flicker."""
    out = []
    ts = list(range(1, 173, 2)) + (list(range(0, 23, 2)) if approach_evens else [])
    for t in sorted(ts):
        k = t / 2
        if k < 11 or t == 22:
            out.append((f"int2_{t:04d}", "cam_int", t / 126))
        else:
            out.append((f"int2_{t:04d}", "cam_int2", (t - 22) / 150))
    return out


if __name__ == "__main__":
    if sys.argv[1] == "setup":
        setup()
    else:
        for n, p, v in frames():
            print(n, p, repr(v))
